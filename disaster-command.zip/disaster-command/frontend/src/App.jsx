import { useState, useEffect, useRef, useCallback } from "react";

// ── Design tokens ──────────────────────────────────────────────────────────
const G = {
  bg:       "#0a0e1a",
  surface:  "#111827",
  card:     "#1a2235",
  border:   "#1e2d45",
  accent:   "#f97316",
  accentLo: "#7c2d12",
  blue:     "#38bdf8",
  blueLo:   "#0c4a6e",
  green:    "#22c55e",
  red:      "#ef4444",
  yellow:   "#eab308",
  purple:   "#a855f7",
  text:     "#e2e8f0",
  muted:    "#64748b",
  grid:     "#0f172a",
};

const css = `
@import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Barlow+Condensed:wght@400;600;700&family=Barlow:wght@400;500&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
body{background:${G.bg};color:${G.text};font-family:'Barlow',sans-serif;font-size:14px;overflow-x:hidden;}
::-webkit-scrollbar{width:4px;}
::-webkit-scrollbar-track{background:#0a0e1a;}
::-webkit-scrollbar-thumb{background:#1e2d45;border-radius:2px;}
.mono{font-family:'Share Tech Mono',monospace;}
.condensed{font-family:'Barlow Condensed',sans-serif;}
.blink{animation:blink 1s step-end infinite;}
@keyframes blink{0%,100%{opacity:1}50%{opacity:0}}
@keyframes slide-in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes fadeUp{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:translateY(0)}}
@keyframes scanline{0%{transform:translateY(-100%)}100%{transform:translateY(100vh)}}
@keyframes flash{0%{background:rgba(249,115,22,0.3)}100%{background:transparent}}
.slide-in{animation:slide-in 0.3s ease-out;}
.flash{animation:flash 0.5s ease-out;}
.fade-up{animation:fadeUp 0.5s ease-out both;}
@keyframes sosPulse{0%,100%{box-shadow:0 0 0 0 rgba(239,68,68,0.7)}70%{box-shadow:0 0 0 16px rgba(239,68,68,0)}}
@keyframes sosRing{0%{transform:scale(1);opacity:1}100%{transform:scale(2.4);opacity:0}}
.sos-pulse{animation:sosPulse 1.4s ease-out infinite;}
.sos-ring{animation:sosRing 1.4s ease-out infinite;}
@keyframes mapPing{0%{transform:scale(1);opacity:1}100%{transform:scale(2.8);opacity:0}}

/* ── Auth styles ── */
.auth-bg{
  min-height:100vh;
  background:${G.bg};
  display:flex;align-items:center;justify-content:center;
  position:relative;overflow:hidden;
}
.auth-grid{
  position:absolute;inset:0;
  background-image:
    linear-gradient(rgba(30,45,69,0.4) 1px,transparent 1px),
    linear-gradient(90deg,rgba(30,45,69,0.4) 1px,transparent 1px);
  background-size:40px 40px;
  pointer-events:none;
}
.auth-scanline{
  position:absolute;top:0;left:0;width:100%;height:40px;
  background:linear-gradient(transparent,rgba(56,189,248,0.03),transparent);
  animation:scanline 4s linear infinite;
  pointer-events:none;
}
.auth-card{
  position:relative;z-index:1;
  width:420px;
  background:${G.surface};
  border:1px solid ${G.border};
  border-radius:12px;
  padding:40px;
  box-shadow:0 0 80px rgba(249,115,22,0.08),0 0 0 1px rgba(249,115,22,0.05);
}
.auth-input{
  width:100%;
  background:${G.card};
  border:1px solid ${G.border};
  color:${G.text};
  padding:10px 14px;
  border-radius:6px;
  font-size:13px;
  font-family:'Barlow',sans-serif;
  outline:none;
  transition:border-color 0.2s,box-shadow 0.2s;
}
.auth-input:focus{
  border-color:${G.accent};
  box-shadow:0 0 0 3px rgba(249,115,22,0.12);
}
.auth-input::placeholder{color:${G.muted};}
.auth-btn{
  width:100%;
  background:${G.accent};
  color:#fff;
  border:none;
  padding:11px 0;
  border-radius:6px;
  font-family:'Barlow Condensed',sans-serif;
  font-weight:700;
  font-size:15px;
  letter-spacing:2px;
  cursor:pointer;
  transition:background 0.2s,box-shadow 0.2s;
}
.auth-btn:hover{background:#ea6c0a;box-shadow:0 0 20px rgba(249,115,22,0.35);}
.auth-btn:disabled{background:${G.accentLo};cursor:not-allowed;}
.auth-link{color:${G.blue};cursor:pointer;}
.auth-link:hover{text-decoration:underline;}
`;

// ── API base URL ───────────────────────────────────────────────────────────
const API = "http://localhost:8000";

// ── Agent / state constants ────────────────────────────────────────────────
const AGENT_INFO = {
  MonitorAgent:        { icon: "📡", color: G.blue,   label: "MONITOR"   },
  ResourceAllocator:   { icon: "⚙️", color: G.yellow, label: "ALLOCATOR" },
  RescueCoordinator:   { icon: "🚁", color: G.green,  label: "RESCUE"    },
  EvaluatorAgent:      { icon: "📊", color: G.purple,  label: "EVALUATOR" },
};

const STATE_COLORS = {
  IDLE:        G.muted,
  MONITORING:  G.blue,
  ALERT:       G.red,
  DISPATCHING: G.yellow,
  RESCUING:    G.green,
  REPLANNING:  G.accent,
  RESOLVED:    G.purple,
};

const GRID_SIZE = 10;
const LOCATIONS_MAP = {
  Downtown: [2,2], Airport: [7,1], Harbor: [1,6], Hospital: [4,4],
  University: [6,6], Industrial: [8,3], Residential: [3,7],
  Suburb: [9,8], Market: [5,2], Stadium: [2,9],
};
const DISASTER_ICONS = {
  flood: "🌊", fire: "🔥", earthquake: "⚡",
  chemical_spill: "☣️", building_collapse: "🏚️",
};

function ts(unix) {
  if (!unix) return "";
  return new Date(unix * 1000).toLocaleTimeString("en-IN", { hour12: false });
}
function severityColor(s) {
  return { LOW: G.green, MEDIUM: G.yellow, HIGH: G.accent, CRITICAL: G.red }[s] || G.muted;
}

// ══════════════════════════════════════════════════════════════════════════
// AUTH PAGES
// ══════════════════════════════════════════════════════════════════════════

function CornerAccents() {
  const corners = [
    { top: 0,    left: 0,    borderTop: true,    borderLeft: true,  borderRadius: "12px 0 0 0" },
    { top: 0,    right: 0,   borderTop: true,    borderRight: true, borderRadius: "0 12px 0 0" },
    { bottom: 0, left: 0,    borderBottom: true, borderLeft: true,  borderRadius: "0 0 0 12px" },
    { bottom: 0, right: 0,   borderBottom: true, borderRight: true, borderRadius: "0 0 12px 0" },
  ];
  return (
    <div style={{ position:"absolute", inset:0, pointerEvents:"none", overflow:"hidden", borderRadius:12 }}>
      {corners.map((c, i) => (
        <div key={i} style={{
          position: "absolute",
          width: 20, height: 20,
          top: c.top, bottom: c.bottom, left: c.left, right: c.right,
          borderTop:    c.borderTop    ? `2px solid ${G.accent}` : "none",
          borderBottom: c.borderBottom ? `2px solid ${G.accent}` : "none",
          borderLeft:   c.borderLeft   ? `2px solid ${G.accent}` : "none",
          borderRight:  c.borderRight  ? `2px solid ${G.accent}` : "none",
          borderRadius: c.borderRadius,
        }} />
      ))}
    </div>
  );
}

function AuthLogo({ subtitle }) {
  return (
    <div style={{ textAlign:"center", marginBottom:28 }}>
      <div style={{ fontSize:40, marginBottom:8 }}>🚨</div>
      <div style={{
        fontFamily:"'Barlow Condensed'", fontWeight:700, fontSize:26,
        letterSpacing:4, color:G.accent,
      }}>DISASTER COMMAND</div>
      <div style={{
        fontFamily:"'Share Tech Mono'", fontSize:10,
        color:G.muted, letterSpacing:2, marginTop:4,
      }}>MULTI-AGENT SIMULATION SYSTEM</div>
      <div style={{
        width:60, height:2,
        background:`linear-gradient(90deg,transparent,${G.accent},transparent)`,
        margin:"12px auto 0",
      }} />
      {subtitle && (
        <div style={{
          fontFamily:"'Barlow Condensed'", fontSize:13,
          letterSpacing:3, color:G.muted, marginTop:14,
        }}>{subtitle}</div>
      )}
    </div>
  );
}

function AuthError({ msg }) {
  if (!msg) return null;
  return (
    <div style={{
      background:"#7f1d1d33", border:`1px solid ${G.red}`,
      borderRadius:5, padding:"8px 12px", color:"#fca5a5", fontSize:12,
    }}>⚠ {msg}</div>
  );
}

function Spinner() {
  return (
    <span style={{
      display:"inline-block", width:14, height:14,
      border:"2px solid #fff", borderTopColor:"transparent",
      borderRadius:"50%", animation:"spin 0.7s linear infinite",
    }} />
  );
}

// ── Login Page ─────────────────────────────────────────────────────────────
function LoginPage({ onLogin, onGoRegister }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");

  const handleSubmit = async () => {
    if (!username || !password) { setError("Fill in all fields"); return; }
    setLoading(true); setError("");
    try {
      const res  = await fetch(`${API}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.detail || "Login failed"); return; }
      onLogin(data.token, username);
    } catch {
      setError("Cannot reach server — is the backend running on port 8000?");
    } finally { setLoading(false); }
  };

  const onKey = (e) => { if (e.key === "Enter") handleSubmit(); };

  return (
    <div className="auth-bg">
      <div className="auth-grid" />
      <div className="auth-scanline" />
      <div className="auth-card fade-up">
        <CornerAccents />
        <AuthLogo subtitle="OPERATOR LOGIN" />

        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <div>
            <label style={{ fontSize:11, color:G.muted, letterSpacing:1,
              fontFamily:"'Barlow Condensed'", display:"block", marginBottom:6 }}>
              USERNAME
            </label>
            <input
              className="auth-input" autoFocus autoComplete="username"
              placeholder="Enter username"
              value={username} onChange={e => setUsername(e.target.value)} onKeyDown={onKey}
            />
          </div>
          <div>
            <label style={{ fontSize:11, color:G.muted, letterSpacing:1,
              fontFamily:"'Barlow Condensed'", display:"block", marginBottom:6 }}>
              PASSWORD
            </label>
            <input
              className="auth-input" type="password"
              placeholder="••••••••" autoComplete="current-password"
              value={password} onChange={e => setPassword(e.target.value)} onKeyDown={onKey}
            />
          </div>

          <AuthError msg={error} />

          <button className="auth-btn" onClick={handleSubmit} disabled={loading}>
            {loading
              ? <span style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:8 }}>
                  <Spinner /> AUTHENTICATING...
                </span>
              : "▶ LOGIN"
            }
          </button>
        </div>

        <div style={{ marginTop:24, textAlign:"center", fontSize:12, color:G.muted }}>
          No account?{" "}
          <span className="auth-link" onClick={onGoRegister}>Create one →</span>
        </div>

        <div style={{
          marginTop:28, padding:"8px 12px", background:G.grid,
          borderRadius:5, display:"flex", alignItems:"center", gap:8,
        }}>
          <div style={{ width:6, height:6, borderRadius:"50%", background:G.green }}
               className="blink" />
          <span style={{ fontFamily:"'Share Tech Mono'", fontSize:10, color:G.muted }}>
            SYS ONLINE · v2.0.0
          </span>
          <span style={{ marginLeft:"auto", fontFamily:"'Share Tech Mono'", fontSize:10, color:G.muted }}>
            {new Date().toLocaleTimeString("en-IN", { hour12:false })}
          </span>
        </div>
      </div>
    </div>
  );
}

// ── Register Page ──────────────────────────────────────────────────────────
function RegisterPage({ onRegistered, onGoLogin }) {
  const [form, setForm] = useState({
    username:"", email:"", password:"", confirm:"", display_name:"",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState("");
  const [success, setSuccess] = useState(false);

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const handleSubmit = async () => {
    if (!form.username || !form.email || !form.password) {
      setError("Username, email and password are required"); return;
    }
    if (form.password !== form.confirm) {
      setError("Passwords do not match"); return;
    }
    if (form.password.length < 6) {
      setError("Password must be at least 6 characters"); return;
    }
    setLoading(true); setError("");
    try {
      const res  = await fetch(`${API}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username:     form.username.trim(),
          email:        form.email.trim(),
          password:     form.password,
          display_name: form.display_name.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.detail || "Registration failed"); return; }
      setSuccess(true);
      setTimeout(() => onRegistered(form.username), 1800);
    } catch {
      setError("Cannot reach server — is the backend running on port 8000?");
    } finally { setLoading(false); }
  };

  const onKey = (e) => { if (e.key === "Enter") handleSubmit(); };

  return (
    <div className="auth-bg">
      <div className="auth-grid" />
      <div className="auth-scanline" />
      <div className="auth-card fade-up" style={{ width:460 }}>
        <CornerAccents />
        <AuthLogo subtitle="NEW OPERATOR REGISTRATION" />

        {success ? (
          <div style={{ textAlign:"center", padding:"32px 0" }}>
            <div style={{ fontSize:48, marginBottom:12 }}>✅</div>
            <div style={{
              fontFamily:"'Barlow Condensed'", fontSize:20,
              color:G.green, letterSpacing:2,
            }}>ACCOUNT CREATED</div>
            <div style={{ color:G.muted, fontSize:12, marginTop:8 }}>
              Redirecting to login...
            </div>
          </div>
        ) : (
          <div style={{ display:"flex", flexDirection:"column", gap:13 }}>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
              <div>
                <label style={{ fontSize:11, color:G.muted, letterSpacing:1,
                  fontFamily:"'Barlow Condensed'", display:"block", marginBottom:5 }}>
                  USERNAME *
                </label>
                <input className="auth-input" autoFocus placeholder="operator_01"
                  value={form.username} onChange={set("username")} onKeyDown={onKey} />
              </div>
              <div>
                <label style={{ fontSize:11, color:G.muted, letterSpacing:1,
                  fontFamily:"'Barlow Condensed'", display:"block", marginBottom:5 }}>
                  DISPLAY NAME
                </label>
                <input className="auth-input" placeholder="John Smith"
                  value={form.display_name} onChange={set("display_name")} onKeyDown={onKey} />
              </div>
            </div>

            <div>
              <label style={{ fontSize:11, color:G.muted, letterSpacing:1,
                fontFamily:"'Barlow Condensed'", display:"block", marginBottom:5 }}>
                EMAIL *
              </label>
              <input className="auth-input" type="email"
                placeholder="operator@command.gov"
                value={form.email} onChange={set("email")} onKeyDown={onKey} />
            </div>

            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
              <div>
                <label style={{ fontSize:11, color:G.muted, letterSpacing:1,
                  fontFamily:"'Barlow Condensed'", display:"block", marginBottom:5 }}>
                  PASSWORD *
                </label>
                <input className="auth-input" type="password" placeholder="••••••••"
                  value={form.password} onChange={set("password")} onKeyDown={onKey} />
              </div>
              <div>
                <label style={{ fontSize:11, color:G.muted, letterSpacing:1,
                  fontFamily:"'Barlow Condensed'", display:"block", marginBottom:5 }}>
                  CONFIRM *
                </label>
                <input className="auth-input" type="password" placeholder="••••••••"
                  value={form.confirm} onChange={set("confirm")} onKeyDown={onKey} />
              </div>
            </div>

            <AuthError msg={error} />

            <button className="auth-btn" onClick={handleSubmit} disabled={loading}
              style={{ marginTop:4 }}>
              {loading
                ? <span style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:8 }}>
                    <Spinner /> CREATING ACCOUNT...
                  </span>
                : "✦ CREATE ACCOUNT"
              }
            </button>
          </div>
        )}

        <div style={{ marginTop:20, textAlign:"center", fontSize:12, color:G.muted }}>
          Already have an account?{" "}
          <span className="auth-link" onClick={onGoLogin}>Sign in →</span>
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// DASHBOARD SUBCOMPONENTS
// ══════════════════════════════════════════════════════════════════════════

function AgentPill({ name, active }) {
  const info = AGENT_INFO[name] || {};
  return (
    <div style={{
      display:"flex", alignItems:"center", gap:8, padding:"8px 12px",
      background: active ? `${info.color}22` : G.card,
      border: `1px solid ${active ? info.color : G.border}`,
      borderRadius:6, transition:"all 0.3s",
      boxShadow: active ? `0 0 12px ${info.color}55` : "none",
    }}>
      <span style={{ fontSize:18 }}>{info.icon}</span>
      <div>
        <div style={{
          fontFamily:"'Barlow Condensed'", fontWeight:700, letterSpacing:1,
          color: active ? info.color : G.muted, fontSize:13,
        }}>{info.label}</div>
        <div style={{ fontSize:10, color:G.muted }}>{name}</div>
      </div>
      {active && (
        <div style={{ marginLeft:"auto", display:"flex", alignItems:"center", gap:4 }}>
          <div className="blink" style={{
            width:6, height:6, borderRadius:"50%", background:info.color,
          }} />
          <span style={{ fontSize:10, color:info.color }}>ACTIVE</span>
        </div>
      )}
    </div>
  );
}

function StateBadge({ state }) {
  const col = STATE_COLORS[state] || G.muted;
  return (
    <div style={{
      display:"inline-flex", alignItems:"center", gap:6,
      padding:"4px 12px", background:`${col}22`, border:`1px solid ${col}`,
      borderRadius:20, color:col, fontFamily:"'Share Tech Mono'", fontSize:12,
      boxShadow:`0 0 8px ${col}44`,
    }}>
      <div style={{ width:6, height:6, borderRadius:"50%", background:col }} />
      {state}
    </div>
  );
}

function MapGrid({ events, resources }) {
  const cellSize = 54;
  const grid = Array.from({ length:GRID_SIZE }, (_, r) =>
    Array.from({ length:GRID_SIZE }, (_, c) => ({ r, c, events:[], resources:[] }))
  );
  events?.forEach(ev => {
    const [gx, gy] = LOCATIONS_MAP[ev.location] || [0, 0];
    if (grid[gy]?.[gx]) grid[gy][gx].events.push(ev);
  });
  resources?.filter(r => r.assigned_to).forEach(res => {
    const [gx, gy] = LOCATIONS_MAP[res.location] || [0, 0];
    if (grid[gy]?.[gx]) grid[gy][gx].resources.push(res);
  });
  return (
    <div style={{ overflowX:"auto" }}>
      <div style={{
        display:"grid",
        gridTemplateColumns:`repeat(${GRID_SIZE},${cellSize}px)`,
        gap:1, background:G.border,
      }}>
        {grid.flat().map((cell, i) => {
          const ev  = cell.events[0];
          const col = ev ? severityColor(ev.severity) : "transparent";
          return (
            <div key={i} title={ev ? `${ev.type} @ ${ev.location}` : ""}
              style={{
                width:cellSize, height:cellSize,
                background: ev ? `${col}18` : G.grid,
                border: ev ? `1px solid ${col}66` : `1px solid ${G.border}`,
                display:"flex", flexDirection:"column",
                alignItems:"center", justifyContent:"center",
                position:"relative", transition:"background 0.3s",
                cursor: ev ? "pointer" : "default",
                boxShadow: ev ? `inset 0 0 12px ${col}33` : "none",
              }}>
              {ev && <>
                <div style={{ fontSize:18 }}>{DISASTER_ICONS[ev.type] || "⚠️"}</div>
                <div style={{ fontSize:8, color:col, fontFamily:"'Share Tech Mono'" }}>
                  {ev.location.slice(0, 6)}
                </div>
              </>}
              {cell.resources.length > 0 && !ev && (
                <div style={{ fontSize:12 }}>🚨</div>
              )}
              {ev && (
                <div className="blink" style={{
                  position:"absolute", top:2, right:2,
                  width:4, height:4, borderRadius:"50%", background:col,
                }} />
              )}
            </div>
          );
        })}
      </div>
      <div style={{ display:"flex", gap:12, marginTop:8, flexWrap:"wrap" }}>
        {Object.entries(DISASTER_ICONS).map(([k, v]) => (
          <span key={k} style={{ fontSize:11, color:G.muted }}>{v} {k.replace("_"," ")}</span>
        ))}
      </div>
    </div>
  );
}

function MessageFeed({ messages }) {
  const ref = useRef();
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [messages]);
  return (
    <div ref={ref} style={{
      height:280, overflowY:"auto", display:"flex", flexDirection:"column", gap:6,
    }}>
      {messages.length === 0 && (
        <div style={{ color:G.muted, textAlign:"center", marginTop:40 }}>
          Run a simulation to see messages
        </div>
      )}
      {messages.map((m, i) => {
        const si = AGENT_INFO[m.sender] || {};
        const ri = AGENT_INFO[m.receiver] || {};
        return (
          <div key={i} className="slide-in" style={{
            background:G.card, border:`1px solid ${G.border}`, borderRadius:6,
            padding:"8px 10px", borderLeft:`3px solid ${si.color || G.muted}`,
          }}>
            <div style={{
              display:"flex", justifyContent:"space-between",
              alignItems:"center", marginBottom:3,
            }}>
              <div style={{ display:"flex", gap:6, alignItems:"center" }}>
                <span style={{ fontSize:12 }}>{si.icon}</span>
                <span style={{
                  color:si.color, fontFamily:"'Barlow Condensed'",
                  fontWeight:700, fontSize:12,
                }}>{m.sender?.split("Agent")[0]?.toUpperCase()}</span>
                <span style={{ color:G.muted, fontSize:10 }}>→</span>
                <span style={{
                  color:ri.color || G.muted, fontFamily:"'Barlow Condensed'", fontSize:12,
                }}>{m.receiver?.split("Agent")[0]?.toUpperCase()}</span>
              </div>
              <span style={{ fontFamily:"'Share Tech Mono'", fontSize:10, color:G.muted }}>
                {ts(m.timestamp)}
              </span>
            </div>
            <div style={{ display:"flex", justifyContent:"space-between" }}>
              <span style={{ fontFamily:"'Share Tech Mono'", fontSize:11, color:G.accent }}>
                {m.msg_type}
              </span>
              {m.payload?.event?.location && (
                <span style={{ fontSize:10, color:G.muted }}>
                  📍 {m.payload.event.location}
                </span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function TransitionTimeline({ transitions }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:4, maxHeight:220, overflowY:"auto" }}>
      {transitions.length === 0 && (
        <div style={{ color:G.muted, fontSize:12, textAlign:"center", padding:20 }}>
          No transitions yet
        </div>
      )}
      {transitions.map((t, i) => (
        <div key={i} className="slide-in" style={{
          display:"flex", alignItems:"center", gap:8,
          padding:"6px 10px", background:G.card,
          borderRadius:5, border:`1px solid ${G.border}`,
        }}>
          <span style={{
            fontSize:10, color:G.muted, fontFamily:"'Share Tech Mono'", minWidth:40,
          }}>{String(i + 1).padStart(2, "0")}</span>
          <StateBadge state={t.from_state} />
          <span style={{ color:G.muted }}>→</span>
          <StateBadge state={t.to_state} />
          <span style={{
            fontSize:10, color:G.muted, marginLeft:"auto",
            maxWidth:140, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap",
          }}>{t.trigger}</span>
        </div>
      ))}
    </div>
  );
}

function MetricCard({ label, value, sub, color = G.blue, icon }) {
  return (
    <div style={{
      background:G.card, border:`1px solid ${G.border}`,
      borderRadius:8, padding:"14px 16px", borderTop:`3px solid ${color}`,
    }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
        <div style={{ fontSize:11, color:G.muted, textTransform:"uppercase", letterSpacing:1 }}>
          {label}
        </div>
        {icon && <span style={{ fontSize:18 }}>{icon}</span>}
      </div>
      <div style={{
        fontFamily:"'Barlow Condensed'", fontSize:32, fontWeight:700,
        color, lineHeight:1.1, marginTop:4,
      }}>{value}</div>
      {sub && <div style={{ fontSize:11, color:G.muted, marginTop:3 }}>{sub}</div>}
    </div>
  );
}

function BarChart({ data, labelKey, valueKey, maxKey, color = G.blue, title }) {
  const max = Math.max(...data.map(d => d[maxKey || valueKey]), 1);
  return (
    <div>
      {title && (
        <div style={{
          fontFamily:"'Barlow Condensed'", fontWeight:700, fontSize:14,
          letterSpacing:1, color:G.muted, marginBottom:8,
        }}>{title}</div>
      )}
      <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
        {data.map((d, i) => (
          <div key={i} style={{ display:"flex", alignItems:"center", gap:8 }}>
            <div style={{
              width:90, fontSize:11, color:G.muted,
              overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap",
            }}>{d[labelKey]}</div>
            <div style={{ flex:1, background:G.grid, borderRadius:3, height:16, position:"relative" }}>
              <div style={{
                width:`${(d[valueKey] / max) * 100}%`, height:"100%",
                background:color, borderRadius:3, transition:"width 0.6s ease", minWidth:4,
              }} />
              {maxKey && (
                <div style={{
                  position:"absolute", top:0, left:0, height:"100%",
                  width:`${(d[maxKey] / max) * 100}%`,
                  background:`${G.muted}44`, borderRadius:3,
                }} />
              )}
            </div>
            <div style={{
              width:36, textAlign:"right",
              fontFamily:"'Share Tech Mono'", fontSize:11, color,
            }}>{d[valueKey]}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AgentLogPanel({ logs }) {
  const ref = useRef();
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [logs]);
  return (
    <div ref={ref} style={{ height:200, overflowY:"auto", fontFamily:"'Share Tech Mono'", fontSize:11 }}>
      {logs.length === 0 && (
        <div style={{ color:G.muted, padding:12 }}>Awaiting agent activity...</div>
      )}
      {logs.map((l, i) => {
        const info = Object.entries(AGENT_INFO)
          .find(([k]) => l.agent?.includes(k.replace("Agent", "")))?.[1] || {};
        return (
          <div key={i} style={{
            display:"flex", gap:8, padding:"3px 0",
            borderBottom:`1px solid ${G.border}22`,
          }}>
            <span style={{ color:G.muted }}>{ts(l.timestamp)}</span>
            <span style={{ color:info.color || G.blue }}>[{info.label || l.agent?.slice(0, 6)}]</span>
            <span style={{ color:G.accent }}>{l.action}</span>
            <span style={{ color:G.text, flex:1 }}>{l.detail}</span>
          </div>
        );
      })}
    </div>
  );
}

function ResourceTable({ resources }) {
  const types = [...new Set(resources.map(r => r.type))];
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
      {types.map(t => {
        const rList = resources.filter(r => r.type === t);
        const avail = rList.filter(r => r.available).length;
        return (
          <div key={t} style={{ display:"flex", alignItems:"center", gap:8 }}>
            <div style={{ width:100, fontSize:12, color:G.muted }}>{t.replace("_", " ")}</div>
            <div style={{ display:"flex", gap:3 }}>
              {rList.map(r => (
                <div key={r.id} title={r.id} style={{
                  width:14, height:14, borderRadius:2,
                  background: r.available ? G.green : G.red,
                  opacity: r.available ? 1 : 0.7,
                  transition:"background 0.3s",
                }} />
              ))}
            </div>
            <div style={{ fontSize:11, color:G.muted, fontFamily:"'Share Tech Mono'" }}>
              {avail}/{rList.length}
            </div>
          </div>
        );
      })}
      <div style={{ fontSize:10, color:G.muted, marginTop:4 }}>
        🟢 Available &nbsp;🔴 Deployed
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// DASHBOARD
// ══════════════════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════════════════
// FEATURE — SCENARIO BUILDER + LIVE INJECT + NLP INPUT
// ══════════════════════════════════════════════════════════════════════════

const DISASTER_TYPES_LIST  = ["flood","fire","earthquake","chemical_spill","building_collapse"];
const LOCATIONS_LIST       = ["Downtown","Airport","Harbor","Hospital","University",
                               "Industrial","Residential","Suburb","Market","Stadium"];
const SEVERITIES_LIST      = ["LOW","MEDIUM","HIGH","CRITICAL"];
const DISASTER_ICONS_MAP   = { flood:"🌊", fire:"🔥", earthquake:"⚡",
                                chemical_spill:"☣️", building_collapse:"🏚️" };
const SEV_COL = { LOW:G.green, MEDIUM:G.yellow, HIGH:G.accent, CRITICAL:G.red };

function emptyEvent() {
  return { type:"fire", severity:"MEDIUM", location:"Downtown", affected_people:100 };
}

function ScenarioBuilder({ token, onRunComplete }) {
  const [subTab, setSubTab]       = useState("form");   // form | nlp | inject

  // Always read fresh token from localStorage
  const getH = () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("dc_token") || token || ""}`,
  });
  const aFetch = (url, opts={}) => fetch(url, { ...opts, headers: { ...getH(), ...(opts.headers||{}) } });

  // ── Form builder state ──
  const [scenarioName, setScenarioName] = useState("My Custom Scenario");
  const [events, setEvents]             = useState([emptyEvent()]);
  const [seed, setSeed]                 = useState(42);
  const [running, setRunning]           = useState(false);
  const [runError, setRunError]         = useState("");

  const addEvent    = () => setEvents(e => [...e, emptyEvent()]);
  const removeEvent = (i) => setEvents(e => e.filter((_, idx) => idx !== i));
  const updateEvent = (i, field, val) =>
    setEvents(e => e.map((ev, idx) => idx === i ? { ...ev, [field]: val } : ev));

  const runCustom = async () => {
    if (events.length === 0) { setRunError("Add at least one event"); return; }
    setRunning(true); setRunError("");
    try {
      const res = await aFetch(`${API}/run/custom`, {
        method:"POST",
        body: JSON.stringify({ name: scenarioName, events, seed }),
      });
      if (!res.ok) { const e = await res.json(); throw new Error(e.detail); }
      const data = await res.json();
      onRunComplete(data, scenarioName);
    } catch(e) { setRunError(e.message); }
    finally { setRunning(false); }
  };

  // ── NLP state ──
  const [nlpText, setNlpText]       = useState("");
  const [nlpParsing, setNlpParsing] = useState(false);
  const [nlpError, setNlpError]     = useState("");
  const [nlpParsed, setNlpParsed]   = useState(null);
  const [nlpRunning, setNlpRunning] = useState(false);

  const parseNLP = async () => {
    if (!nlpText.trim()) return;
    setNlpParsing(true); setNlpError(""); setNlpParsed(null);
    try {
      const res = await aFetch(`${API}/run/nlp-parse`, {
        method:"POST",
        body: JSON.stringify({ text: nlpText }),
      });
      if (!res.ok) { const e = await res.json(); throw new Error(e.detail); }
      const d = await res.json();
      setNlpParsed(d.parsed);
      if (d.source === "local_fallback" && d.api_error) {
        setNlpError(`⚠ AI unavailable — used local rule-based parser instead`);
      } else if (d.source === "local") {
        setNlpError("💡 Tip: Set ANTHROPIC_API_KEY for AI-powered parsing");
      }
    } catch(e) { setNlpError(e.message); }
    finally { setNlpParsing(false); }
  };

  const runNLP = async () => {
    if (!nlpParsed) return;
    setNlpRunning(true); setNlpError("");
    try {
      const res = await aFetch(`${API}/run/custom`, {
        method:"POST",
        body: JSON.stringify({ ...nlpParsed, seed }),
      });
      if (!res.ok) { const e = await res.json(); throw new Error(e.detail); }
      const data = await res.json();
      onRunComplete(data, nlpParsed.name || "NLP Scenario");
    } catch(e) { setNlpError(e.message); }
    finally { setNlpRunning(false); }
  };

  const loadIntoForm = () => {
    if (!nlpParsed) return;
    setScenarioName(nlpParsed.name || "NLP Scenario");
    setEvents(nlpParsed.events || [emptyEvent()]);
    setSubTab("form");
  };

  // ── Live inject state ──
  const [injectEv, setInjectEv]     = useState(emptyEvent());
  const [injecting, setInjecting]   = useState(false);
  const [injectOk, setInjectOk]     = useState(false);
  const [injectError, setInjectError] = useState("");

  const injectEvent = async () => {
    setInjecting(true); setInjectError(""); setInjectOk(false);
    try {
      const res = await aFetch(`${API}/run/inject`, {
        method:"POST",
        body: JSON.stringify({ ...injectEv, seed }),
      });
      if (!res.ok) { const e = await res.json(); throw new Error(e.detail); }
      const data = await res.json();
      setInjectOk(true);
      onRunComplete(data, `Injected: ${injectEv.type} @ ${injectEv.location}`);
      setTimeout(() => setInjectOk(false), 3000);
    } catch(e) { setInjectError(e.message); }
    finally { setInjecting(false); }
  };

  const SUB_TABS = [
    { id:"form",   label:"🗂 Form Builder"    },
    { id:"nlp",    label:"🤖 AI Input"        },
    { id:"inject", label:"⚡ Live Inject"     },
  ];

  const inputStyle = {
    background:G.card, border:`1px solid ${G.border}`,
    color:G.text, padding:"8px 10px", borderRadius:5,
    fontSize:12, fontFamily:"'Barlow',sans-serif", outline:"none",
    width:"100%",
  };
  const labelStyle = {
    fontSize:10, color:G.muted, letterSpacing:1,
    fontFamily:"'Barlow Condensed'", display:"block", marginBottom:4,
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:16 }}>

      {/* Sub-tab bar */}
      <div style={{ display:"flex", gap:4, background:G.grid, borderRadius:8, padding:4 }}>
        {SUB_TABS.map(t => (
          <button key={t.id} onClick={() => setSubTab(t.id)} style={{
            flex:1, padding:"9px 0",
            background: subTab === t.id ? G.card : "none",
            border: subTab === t.id ? `1px solid ${G.border}` : "1px solid transparent",
            borderRadius:6, cursor:"pointer",
            fontFamily:"'Barlow Condensed'", fontWeight:700, letterSpacing:1, fontSize:13,
            color: subTab === t.id ? G.accent : G.muted, transition:"all 0.2s",
          }}>{t.label}</button>
        ))}
      </div>

      {/* ══ FORM BUILDER ══ */}
      {subTab === "form" && (
        <div style={{ display:"flex", flexDirection:"column", gap:16 }}>

          {/* Scenario name + seed */}
          <div style={{ display:"grid", gridTemplateColumns:"1fr auto", gap:12 }}>
            <div>
              <label style={labelStyle}>SCENARIO NAME</label>
              <input style={inputStyle} value={scenarioName}
                onChange={e => setScenarioName(e.target.value)}
                onFocus={e => e.target.style.borderColor = G.accent}
                onBlur={e  => e.target.style.borderColor = G.border}
              />
            </div>
            <div style={{ minWidth:110 }}>
              <label style={labelStyle}>RANDOM SEED</label>
              <input type="number" style={inputStyle} value={seed}
                onChange={e => setSeed(parseInt(e.target.value)||42)}
                onFocus={e => e.target.style.borderColor = G.accent}
                onBlur={e  => e.target.style.borderColor = G.border}
              />
            </div>
          </div>

          {/* Event rows */}
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <div style={{
                fontFamily:"'Barlow Condensed'", fontWeight:700,
                letterSpacing:2, fontSize:11, color:G.muted,
              }}>DISASTER EVENTS ({events.length})</div>
              <button onClick={addEvent} style={{
                background:`${G.green}18`, border:`1px solid ${G.green}44`,
                color:G.green, padding:"5px 14px", borderRadius:5,
                cursor:"pointer", fontFamily:"'Barlow Condensed'",
                fontWeight:700, fontSize:12, letterSpacing:1,
              }}>+ ADD EVENT</button>
            </div>

            {events.map((ev, i) => (
              <div key={i} style={{
                background:G.card, border:`1px solid ${G.border}`,
                borderLeft:`4px solid ${SEV_COL[ev.severity]}`,
                borderRadius:8, padding:14,
              }}>
                <div style={{
                  display:"grid",
                  gridTemplateColumns:"auto 1fr 1fr 1fr 1fr auto",
                  gap:12, alignItems:"end",
                }}>
                  {/* Index */}
                  <div style={{
                    width:28, height:28, borderRadius:"50%",
                    background:`${SEV_COL[ev.severity]}22`,
                    border:`1px solid ${SEV_COL[ev.severity]}55`,
                    display:"flex", alignItems:"center", justifyContent:"center",
                    fontFamily:"'Share Tech Mono'", fontSize:11,
                    color:SEV_COL[ev.severity], flexShrink:0,
                  }}>{i+1}</div>

                  {/* Type */}
                  <div>
                    <label style={labelStyle}>TYPE</label>
                    <select style={inputStyle} value={ev.type}
                      onChange={e => updateEvent(i,"type",e.target.value)}>
                      {DISASTER_TYPES_LIST.map(t => (
                        <option key={t} value={t}>
                          {DISASTER_ICONS_MAP[t]} {t.replace("_"," ")}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Location */}
                  <div>
                    <label style={labelStyle}>LOCATION</label>
                    <select style={inputStyle} value={ev.location}
                      onChange={e => updateEvent(i,"location",e.target.value)}>
                      {LOCATIONS_LIST.map(l => (
                        <option key={l} value={l}>{l}</option>
                      ))}
                    </select>
                  </div>

                  {/* Severity */}
                  <div>
                    <label style={labelStyle}>SEVERITY</label>
                    <select style={{...inputStyle, color:SEV_COL[ev.severity]}}
                      value={ev.severity}
                      onChange={e => updateEvent(i,"severity",e.target.value)}>
                      {SEVERITIES_LIST.map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>

                  {/* Affected people */}
                  <div>
                    <label style={labelStyle}>PEOPLE AFFECTED</label>
                    <input type="number" min={1} max={2000} style={inputStyle}
                      value={ev.affected_people}
                      onChange={e => updateEvent(i,"affected_people",parseInt(e.target.value)||1)}
                      onFocus={e => e.target.style.borderColor = G.accent}
                      onBlur={e  => e.target.style.borderColor = G.border}
                    />
                  </div>

                  {/* Remove */}
                  <button onClick={() => removeEvent(i)} style={{
                    background:"none", border:`1px solid ${G.border}`,
                    color:G.muted, width:32, height:32, borderRadius:5,
                    cursor:"pointer", fontSize:14, flexShrink:0,
                    display:"flex", alignItems:"center", justifyContent:"center",
                    transition:"all 0.15s",
                  }}
                  onMouseOver={e => { e.currentTarget.style.borderColor=G.red; e.currentTarget.style.color=G.red; }}
                  onMouseOut={e  => { e.currentTarget.style.borderColor=G.border; e.currentTarget.style.color=G.muted; }}>
                    ✕
                  </button>
                </div>

                {/* Severity slider */}
                <div style={{ marginTop:10, display:"flex", alignItems:"center", gap:10 }}>
                  <span style={{ fontSize:9, color:G.muted, fontFamily:"'Share Tech Mono'", width:60 }}>
                    PEOPLE
                  </span>
                  <input type="range" min={1} max={1000}
                    value={ev.affected_people}
                    onChange={e => updateEvent(i,"affected_people",parseInt(e.target.value))}
                    style={{ flex:1, accentColor: SEV_COL[ev.severity] }}
                  />
                  <span style={{
                    fontSize:12, color:SEV_COL[ev.severity],
                    fontFamily:"'Share Tech Mono'", minWidth:36, textAlign:"right",
                  }}>{ev.affected_people}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Preview */}
          <div style={{
            background:G.grid, borderRadius:8, padding:14,
            border:`1px solid ${G.border}`,
            fontFamily:"'Share Tech Mono'", fontSize:11, color:G.muted,
          }}>
            <div style={{ color:G.accent, marginBottom:6, letterSpacing:1 }}>SCENARIO PREVIEW</div>
            <div style={{ color:G.text }}>{scenarioName}</div>
            <div style={{ marginTop:4 }}>
              {events.map((ev, i) => (
                <div key={i} style={{ color:SEV_COL[ev.severity], marginTop:2 }}>
                  {DISASTER_ICONS_MAP[ev.type]} {ev.type} @ {ev.location} · {ev.severity} · {ev.affected_people} people
                </div>
              ))}
            </div>
            <div style={{ marginTop:6, color:G.muted }}>
              Total at risk: {events.reduce((s,e) => s + e.affected_people, 0)} · Seed: {seed}
            </div>
          </div>

          {runError && (
            <div style={{
              background:"#7f1d1d33", border:`1px solid ${G.red}`,
              borderRadius:5, padding:"8px 12px", color:"#fca5a5", fontSize:12,
            }}>⚠ {runError}</div>
          )}

          <button onClick={runCustom} disabled={running || events.length === 0} style={{
            background: running ? G.accentLo : G.accent,
            color:"#fff", border:"none", padding:"12px 0", borderRadius:6,
            fontFamily:"'Barlow Condensed'", fontWeight:700, letterSpacing:2, fontSize:15,
            cursor: running ? "not-allowed" : "pointer",
            display:"flex", alignItems:"center", justifyContent:"center", gap:10,
            transition:"background 0.2s",
          }}>
            {running
              ? <><div style={{ width:14, height:14, border:"2px solid #fff",
                  borderTopColor:"transparent", borderRadius:"50%",
                  animation:"spin 0.7s linear infinite" }} />RUNNING SIMULATION...</>
              : `▶ RUN "${scenarioName}"`
            }
          </button>
        </div>
      )}

      {/* ══ NLP / AI INPUT ══ */}
      {subTab === "nlp" && (
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>

          <div style={{
            background:`${G.purple}11`, border:`1px solid ${G.purple}33`,
            borderRadius:8, padding:14, fontSize:12, color:G.muted, lineHeight:1.6,
          }}>
            <span style={{ color:G.purple, fontWeight:700 }}>🤖 AI Scenario Parser</span> — Describe any disaster in plain English.
            Claude will extract the disaster type, location, severity and affected people automatically.
          </div>

          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            {/* Quick examples */}
            <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
              {[
                "A major flood near the harbor affecting 300 people",
                "Critical chemical spill at the industrial zone, 500 casualties",
                "Two simultaneous fires at the airport and market, moderate severity",
                "Massive earthquake downtown, 600 people trapped, critical situation",
              ].map(ex => (
                <button key={ex} onClick={() => setNlpText(ex)} style={{
                  background:G.card, border:`1px solid ${G.border}`,
                  color:G.muted, padding:"4px 10px", borderRadius:12,
                  cursor:"pointer", fontSize:11, fontFamily:"'Barlow',sans-serif",
                  transition:"all 0.15s",
                }}
                onMouseOver={e => { e.currentTarget.style.borderColor=G.purple; e.currentTarget.style.color=G.purple; }}
                onMouseOut={e  => { e.currentTarget.style.borderColor=G.border; e.currentTarget.style.color=G.muted; }}>
                  {ex.slice(0, 40)}…
                </button>
              ))}
            </div>

            <label style={labelStyle}>DESCRIBE THE EMERGENCY SCENARIO</label>
            <textarea
              value={nlpText} onChange={e => setNlpText(e.target.value)}
              placeholder="e.g. There's a serious flood at the harbor affecting around 200 people, and a fire has broken out at the airport..."
              rows={5}
              style={{
                ...inputStyle, resize:"vertical", lineHeight:1.6,
              }}
              onFocus={e => e.target.style.borderColor = G.purple}
              onBlur={e  => e.target.style.borderColor = G.border}
            />
          </div>

          <div style={{ display:"flex", gap:10, alignItems:"center" }}>
            <button onClick={parseNLP} disabled={nlpParsing || !nlpText.trim()} style={{
              background:`${G.purple}22`, border:`1px solid ${G.purple}66`,
              color:G.purple, padding:"10px 20px", borderRadius:6,
              fontFamily:"'Barlow Condensed'", fontWeight:700, letterSpacing:1, fontSize:13,
              cursor: nlpParsing || !nlpText.trim() ? "not-allowed" : "pointer",
              display:"flex", alignItems:"center", gap:8,
            }}>
              {nlpParsing
                ? <><div style={{ width:12, height:12, border:"2px solid currentColor",
                    borderTopColor:"transparent", borderRadius:"50%",
                    animation:"spin 0.7s linear infinite" }} />PARSING...</>
                : "🤖 PARSE WITH AI"
              }
            </button>
            <div style={{ fontSize:11, color:G.muted, fontFamily:"'Share Tech Mono'" }}>
              powered by Claude
            </div>
          </div>

          {nlpError && (
            <div style={{
              background:"#7f1d1d33", border:`1px solid ${G.red}`,
              borderRadius:5, padding:"8px 12px", color:"#fca5a5", fontSize:12,
            }}>⚠ {nlpError}</div>
          )}

          {/* Parsed result */}
          {nlpParsed && (
            <div style={{
              background:G.card, border:`1px solid ${G.green}44`,
              borderRadius:8, padding:16, animation:"slide-in 0.3s ease-out",
            }}>
              <div style={{
                fontFamily:"'Barlow Condensed'", fontWeight:700,
                letterSpacing:2, fontSize:12, color:G.green, marginBottom:12,
              }}>✓ PARSED SCENARIO — "{nlpParsed.name}"</div>

              <div style={{ display:"flex", flexDirection:"column", gap:8, marginBottom:14 }}>
                {(nlpParsed.events || []).map((ev, i) => (
                  <div key={i} style={{
                    display:"flex", alignItems:"center", gap:12,
                    background:G.grid, borderRadius:6, padding:"8px 12px",
                    border:`1px solid ${SEV_COL[ev.severity]}33`,
                  }}>
                    <span style={{ fontSize:20 }}>{DISASTER_ICONS_MAP[ev.type] || "⚠️"}</span>
                    <div style={{ flex:1 }}>
                      <span style={{ color:G.text, fontSize:13 }}>
                        {ev.type.replace("_"," ")} @ <strong>{ev.location}</strong>
                      </span>
                    </div>
                    <span style={{
                      padding:"2px 8px", borderRadius:10, fontSize:10,
                      background:`${SEV_COL[ev.severity]}22`,
                      color:SEV_COL[ev.severity],
                      border:`1px solid ${SEV_COL[ev.severity]}44`,
                      fontFamily:"'Share Tech Mono'",
                    }}>{ev.severity}</span>
                    <span style={{
                      fontSize:11, color:G.muted, fontFamily:"'Share Tech Mono'", minWidth:60, textAlign:"right",
                    }}>{ev.affected_people} ppl</span>
                  </div>
                ))}
              </div>

              <div style={{ display:"flex", gap:10 }}>
                <button onClick={runNLP} disabled={nlpRunning} style={{
                  flex:1, background:G.accent, color:"#fff", border:"none",
                  padding:"10px 0", borderRadius:6,
                  fontFamily:"'Barlow Condensed'", fontWeight:700, letterSpacing:1, fontSize:13,
                  cursor: nlpRunning ? "not-allowed" : "pointer",
                  display:"flex", alignItems:"center", justifyContent:"center", gap:8,
                }}>
                  {nlpRunning
                    ? <><div style={{ width:12, height:12, border:"2px solid #fff",
                        borderTopColor:"transparent", borderRadius:"50%",
                        animation:"spin 0.7s linear infinite" }} />RUNNING...</>
                    : "▶ RUN THIS SCENARIO"
                  }
                </button>
                <button onClick={loadIntoForm} style={{
                  background:G.card, border:`1px solid ${G.border}`,
                  color:G.text, padding:"10px 16px", borderRadius:6,
                  fontFamily:"'Barlow Condensed'", fontWeight:700, letterSpacing:1, fontSize:12,
                  cursor:"pointer",
                }}>EDIT IN FORM →</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ══ LIVE INJECT ══ */}
      {subTab === "inject" && (
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>

          <div style={{
            background:`${G.accent}11`, border:`1px solid ${G.accent}33`,
            borderRadius:8, padding:14, fontSize:12, color:G.muted, lineHeight:1.6,
          }}>
            <span style={{ color:G.accent, fontWeight:700 }}>⚡ Live Inject</span> — Add a new disaster event
            to the current simulation in real-time. The agents will immediately replan and respond.
            Works even with no active run.
          </div>

          {/* Visual grid for location picking */}
          <div>
            <label style={{...labelStyle, marginBottom:8}}>CLICK LOCATION ON GRID</label>
            <div style={{
              display:"grid", gridTemplateColumns:"repeat(5, 1fr)",
              gap:6,
            }}>
              {LOCATIONS_LIST.map(loc => (
                <button key={loc} onClick={() => setInjectEv(e => ({...e, location:loc}))} style={{
                  padding:"8px 4px", borderRadius:6, cursor:"pointer",
                  background: injectEv.location === loc ? `${G.accent}22` : G.card,
                  border: `1px solid ${injectEv.location === loc ? G.accent : G.border}`,
                  color: injectEv.location === loc ? G.accent : G.muted,
                  fontFamily:"'Barlow Condensed'", fontWeight:700,
                  fontSize:11, letterSpacing:1, transition:"all 0.15s",
                  textAlign:"center",
                }}>{loc}</button>
              ))}
            </div>
          </div>

          {/* Type picker */}
          <div>
            <label style={labelStyle}>DISASTER TYPE</label>
            <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
              {DISASTER_TYPES_LIST.map(t => (
                <button key={t} onClick={() => setInjectEv(e => ({...e, type:t}))} style={{
                  padding:"8px 14px", borderRadius:6, cursor:"pointer",
                  background: injectEv.type === t ? `${G.blue}22` : G.card,
                  border: `1px solid ${injectEv.type === t ? G.blue : G.border}`,
                  color: injectEv.type === t ? G.blue : G.muted,
                  fontFamily:"'Barlow Condensed'", fontWeight:700,
                  fontSize:12, letterSpacing:1, transition:"all 0.15s",
                  display:"flex", alignItems:"center", gap:6,
                }}>
                  <span>{DISASTER_ICONS_MAP[t]}</span>
                  <span>{t.replace("_"," ")}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Severity + people sliders */}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
            <div>
              <label style={labelStyle}>SEVERITY</label>
              <div style={{ display:"flex", gap:6 }}>
                {SEVERITIES_LIST.map(s => (
                  <button key={s} onClick={() => setInjectEv(e => ({...e, severity:s}))} style={{
                    flex:1, padding:"8px 0",
                    background: injectEv.severity === s ? `${SEV_COL[s]}22` : G.card,
                    border:`1px solid ${injectEv.severity === s ? SEV_COL[s] : G.border}`,
                    borderRadius:5, cursor:"pointer",
                    fontFamily:"'Barlow Condensed'", fontWeight:700, fontSize:10, letterSpacing:1,
                    color: injectEv.severity === s ? SEV_COL[s] : G.muted,
                    transition:"all 0.15s",
                  }}>{s}</button>
                ))}
              </div>
            </div>
            <div>
              <label style={labelStyle}>PEOPLE AFFECTED: {injectEv.affected_people}</label>
              <input type="range" min={10} max={1000}
                value={injectEv.affected_people}
                onChange={e => setInjectEv(ev => ({...ev, affected_people: parseInt(e.target.value)}))}
                style={{ width:"100%", accentColor: SEV_COL[injectEv.severity], marginTop:8 }}
              />
              <div style={{
                display:"flex", justifyContent:"space-between",
                fontSize:9, color:G.muted, fontFamily:"'Share Tech Mono'",
              }}>
                <span>10</span><span>1000</span>
              </div>
            </div>
          </div>

          {/* Preview */}
          <div style={{
            background:G.grid, borderRadius:8, padding:14,
            border:`1px solid ${SEV_COL[injectEv.severity]}44`,
            display:"flex", alignItems:"center", gap:16,
          }}>
            <span style={{ fontSize:36 }}>{DISASTER_ICONS_MAP[injectEv.type]}</span>
            <div>
              <div style={{ fontFamily:"'Barlow Condensed'", fontSize:16, color:G.text }}>
                {injectEv.type.replace("_"," ").toUpperCase()} @ {injectEv.location.toUpperCase()}
              </div>
              <div style={{ fontFamily:"'Share Tech Mono'", fontSize:11, marginTop:2 }}>
                <span style={{ color:SEV_COL[injectEv.severity] }}>{injectEv.severity}</span>
                <span style={{ color:G.muted }}> · {injectEv.affected_people} people at risk</span>
              </div>
            </div>
            <div style={{ marginLeft:"auto" }}>
              <div style={{
                width:8, height:8, borderRadius:"50%",
                background:SEV_COL[injectEv.severity],
                boxShadow:`0 0 10px ${SEV_COL[injectEv.severity]}`,
              }} className="blink" />
            </div>
          </div>

          {injectOk && (
            <div style={{
              background:`${G.green}18`, border:`1px solid ${G.green}`,
              borderRadius:6, padding:"10px 14px", color:G.green, fontSize:12,
              fontFamily:"'Share Tech Mono'",
            }}>✓ EVENT INJECTED — agents are responding</div>
          )}
          {injectError && (
            <div style={{
              background:"#7f1d1d33", border:`1px solid ${G.red}`,
              borderRadius:5, padding:"8px 12px", color:"#fca5a5", fontSize:12,
            }}>⚠ {injectError}</div>
          )}

          <button onClick={injectEvent} disabled={injecting} style={{
            background: injecting ? G.accentLo : `${G.red}cc`,
            color:"#fff", border:"none", padding:"12px 0", borderRadius:6,
            fontFamily:"'Barlow Condensed'", fontWeight:700, letterSpacing:2, fontSize:15,
            cursor: injecting ? "not-allowed" : "pointer",
            display:"flex", alignItems:"center", justifyContent:"center", gap:10,
            transition:"background 0.2s",
          }}>
            {injecting
              ? <><div style={{ width:14, height:14, border:"2px solid #fff",
                  borderTopColor:"transparent", borderRadius:"50%",
                  animation:"spin 0.7s linear infinite" }} />INJECTING...</>
              : `⚡ INJECT ${injectEv.type.toUpperCase()} @ ${injectEv.location.toUpperCase()}`
            }
          </button>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// FEATURE — SOS EMERGENCY PANEL
// ══════════════════════════════════════════════════════════════════════════

const SOS_SEVERITIES = ["LOW","MEDIUM","HIGH","CRITICAL"];
const SEV_COLOR = { LOW:G.green, MEDIUM:G.yellow, HIGH:G.accent, CRITICAL:G.red };
const STATUS_COLOR = { OPEN:G.red, ACKNOWLEDGED:G.yellow, RESOLVED:G.green };

function SOSPanel({ token, user }) {
  const [tab, setTab]           = useState("send");   // send | inbox
  const [alerts, setAlerts]     = useState([]);
  const [loadingAlerts, setLoadingAlerts] = useState(false);

  // Form state
  const [message, setMessage]   = useState("");
  const [severity, setSeverity] = useState("HIGH");
  const [locName, setLocName]   = useState("");
  const [lat, setLat]           = useState("");
  const [lng, setLng]           = useState("");
  const [locLoading, setLocLoading] = useState(false);
  const [sending, setSending]   = useState(false);
  const [sent, setSent]         = useState(false);
  const [error, setError]       = useState("");

  const headers = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("dc_token") || token || ""}`,
  };
  const getH = () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("dc_token") || token || ""}`,
  });

  const fetchAlerts = async () => {
    setLoadingAlerts(true);
    try {
      const r = await fetch(`${API}/sos`, { headers });
      const d = await r.json();
      setAlerts(d.alerts || []);
    } catch {}
    finally { setLoadingAlerts(false); }
  };

  useEffect(() => { if (tab === "inbox") fetchAlerts(); }, [tab]);

  const getLocation = () => {
    if (!navigator.geolocation) { setError("Geolocation not supported"); return; }
    setLocLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLat(pos.coords.latitude.toFixed(6));
        setLng(pos.coords.longitude.toFixed(6));
        setLocName(`${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`);
        setLocLoading(false);
      },
      () => { setError("Could not get location"); setLocLoading(false); },
    );
  };

  const handleSend = async () => {
    if (!message.trim()) { setError("Please describe the emergency"); return; }
    setSending(true); setError("");
    try {
      const r = await fetch(`${API}/sos`, {
        method:"POST", headers,
        body: JSON.stringify({
          message, severity,
          latitude:  lat  || null,
          longitude: lng  || null,
          location_name: locName || null,
        }),
      });
      if (!r.ok) { const e = await r.json(); throw new Error(e.detail); }
      setSent(true);
      setTimeout(() => {
        setSent(false); setMessage(""); setLocName(""); setLat(""); setLng("");
      }, 3000);
    } catch(e) { setError(e.message); }
    finally { setSending(false); }
  };

  const updateStatus = async (id, status, note="") => {
    try {
      await fetch(`${API}/sos/${id}`, {
        method:"PATCH", headers,
        body: JSON.stringify({ status, admin_note: note }),
      });
      fetchAlerts();
    } catch {}
  };

  const openAlerts  = alerts.filter(a => a.status === "OPEN");
  const ackAlerts   = alerts.filter(a => a.status === "ACKNOWLEDGED");
  const doneAlerts  = alerts.filter(a => a.status === "RESOLVED");

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:16 }}>

      {/* Sub-tabs */}
      <div style={{ display:"flex", gap:0, background:G.grid, borderRadius:8, padding:4 }}>
        {[
          { id:"send",  label:"🆘 Send SOS" },
          { id:"inbox", label:`📥 Alerts${openAlerts.length > 0 && tab === "inbox" ? ` (${openAlerts.length})` : ""}` },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            flex:1, padding:"9px 0", background: tab === t.id ? G.card : "none",
            border: tab === t.id ? `1px solid ${G.border}` : "1px solid transparent",
            borderRadius:6, cursor:"pointer",
            fontFamily:"'Barlow Condensed'", fontWeight:700, letterSpacing:1, fontSize:13,
            color: tab === t.id ? G.accent : G.muted, transition:"all 0.2s",
          }}>{t.label}</button>
        ))}
      </div>

      {/* ── SEND SOS ── */}
      {tab === "send" && (
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>

          {/* Left — form */}
          <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
            {sent ? (
              <div style={{
                background:`${G.green}18`, border:`2px solid ${G.green}`,
                borderRadius:12, padding:"32px 20px", textAlign:"center",
              }}>
                <div style={{ fontSize:48, marginBottom:12 }}>✅</div>
                <div style={{
                  fontFamily:"'Barlow Condensed'", fontSize:22,
                  color:G.green, letterSpacing:2,
                }}>SOS SENT</div>
                <div style={{ color:G.muted, fontSize:12, marginTop:6 }}>
                  Emergency transmitted to command
                </div>
              </div>
            ) : (
              <>
                {/* Big SOS button */}
                <div style={{ display:"flex", justifyContent:"center", marginBottom:4 }}>
                  <div style={{ position:"relative", display:"flex", alignItems:"center", justifyContent:"center" }}>
                    <div className="sos-ring" style={{
                      position:"absolute", width:100, height:100,
                      borderRadius:"50%", border:`3px solid ${G.red}`,
                    }} />
                    <button
                      onClick={handleSend} disabled={sending}
                      className="sos-pulse"
                      style={{
                        width:90, height:90, borderRadius:"50%",
                        background: sending ? G.accentLo : G.red,
                        border:`3px solid ${G.red}`,
                        fontFamily:"'Barlow Condensed'", fontWeight:700,
                        fontSize:20, letterSpacing:3, color:"#fff",
                        cursor: sending ? "not-allowed" : "pointer",
                        display:"flex", alignItems:"center", justifyContent:"center",
                        flexDirection:"column", gap:2,
                      }}>
                      {sending
                        ? <div style={{ width:20, height:20, border:"3px solid #fff",
                            borderTopColor:"transparent", borderRadius:"50%",
                            animation:"spin 0.7s linear infinite" }} />
                        : <>🆘<span style={{ fontSize:13 }}>SOS</span></>
                      }
                    </button>
                  </div>
                </div>

                {/* Severity */}
                <div>
                  <label style={{ fontSize:11, color:G.muted, letterSpacing:1,
                    fontFamily:"'Barlow Condensed'", display:"block", marginBottom:6 }}>
                    EMERGENCY LEVEL
                  </label>
                  <div style={{ display:"flex", gap:6 }}>
                    {SOS_SEVERITIES.map(s => (
                      <button key={s} onClick={() => setSeverity(s)} style={{
                        flex:1, padding:"7px 0",
                        background: severity === s ? `${SEV_COLOR[s]}22` : G.card,
                        border: `1px solid ${severity === s ? SEV_COLOR[s] : G.border}`,
                        borderRadius:5, cursor:"pointer",
                        fontFamily:"'Barlow Condensed'", fontWeight:700,
                        fontSize:11, letterSpacing:1,
                        color: severity === s ? SEV_COLOR[s] : G.muted,
                        transition:"all 0.15s",
                      }}>{s}</button>
                    ))}
                  </div>
                </div>

                {/* Message */}
                <div>
                  <label style={{ fontSize:11, color:G.muted, letterSpacing:1,
                    fontFamily:"'Barlow Condensed'", display:"block", marginBottom:6 }}>
                    EMERGENCY MESSAGE *
                  </label>
                  <textarea
                    value={message} onChange={e => setMessage(e.target.value)}
                    placeholder="Describe the emergency — what happened, how many people, what is needed..."
                    rows={4}
                    style={{
                      width:"100%", background:G.card, border:`1px solid ${G.border}`,
                      color:G.text, padding:"10px 14px", borderRadius:6,
                      fontSize:13, fontFamily:"'Barlow',sans-serif", resize:"vertical",
                      outline:"none",
                    }}
                    onFocus={e => e.target.style.borderColor = G.accent}
                    onBlur={e  => e.target.style.borderColor = G.border}
                  />
                </div>

                {error && (
                  <div style={{
                    background:"#7f1d1d33", border:`1px solid ${G.red}`,
                    borderRadius:5, padding:"8px 12px", color:"#fca5a5", fontSize:12,
                  }}>⚠ {error}</div>
                )}
              </>
            )}
          </div>

          {/* Right — location */}
          <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
            <div style={{
              background:G.grid, borderRadius:8, padding:16,
              border:`1px solid ${G.border}`,
            }}>
              <div style={{
                fontFamily:"'Barlow Condensed'", fontWeight:700,
                letterSpacing:2, fontSize:12, color:G.muted, marginBottom:12,
              }}>📍 LOCATION</div>

              <button onClick={getLocation} disabled={locLoading} style={{
                width:"100%", background: lat ? `${G.green}18` : G.card,
                border:`1px solid ${lat ? G.green : G.border}`,
                color: lat ? G.green : G.text,
                padding:"10px", borderRadius:6, cursor:"pointer",
                fontFamily:"'Barlow Condensed'", fontWeight:700,
                fontSize:13, letterSpacing:1, marginBottom:10,
                display:"flex", alignItems:"center", justifyContent:"center", gap:8,
              }}>
                {locLoading
                  ? <><div style={{ width:12, height:12, border:"2px solid currentColor",
                      borderTopColor:"transparent", borderRadius:"50%",
                      animation:"spin 0.7s linear infinite" }} />DETECTING...</>
                  : lat ? "✓ LOCATION CAPTURED" : "📍 GET MY LOCATION"
                }
              </button>

              {lat && lng && (
                <div style={{
                  background:G.card, borderRadius:6, padding:"10px 12px",
                  fontFamily:"'Share Tech Mono'", fontSize:11, color:G.muted,
                  marginBottom:10,
                }}>
                  <div style={{ color:G.green, marginBottom:4 }}>GPS LOCKED</div>
                  <div>LAT: <span style={{ color:G.text }}>{lat}</span></div>
                  <div>LNG: <span style={{ color:G.text }}>{lng}</span></div>
                </div>
              )}

              <div>
                <label style={{ fontSize:11, color:G.muted, letterSpacing:1,
                  fontFamily:"'Barlow Condensed'", display:"block", marginBottom:5 }}>
                  LOCATION DESCRIPTION
                </label>
                <input
                  value={locName} onChange={e => setLocName(e.target.value)}
                  placeholder="e.g. Near Koramangala flyover, 3rd floor"
                  style={{
                    width:"100%", background:G.card, border:`1px solid ${G.border}`,
                    color:G.text, padding:"9px 12px", borderRadius:5,
                    fontSize:12, fontFamily:"'Barlow',sans-serif", outline:"none",
                  }}
                  onFocus={e => e.target.style.borderColor = G.accent}
                  onBlur={e  => e.target.style.borderColor = G.border}
                />
              </div>
            </div>

            {/* Operator info card */}
            <div style={{
              background:`${G.accent}11`, border:`1px solid ${G.accent}44`,
              borderRadius:8, padding:14,
            }}>
              <div style={{
                fontFamily:"'Barlow Condensed'", fontWeight:700,
                letterSpacing:2, fontSize:11, color:G.accent, marginBottom:8,
              }}>SENDING AS</div>
              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                <div style={{
                  width:32, height:32, borderRadius:"50%", background:G.accent,
                  display:"flex", alignItems:"center", justifyContent:"center",
                  fontSize:14, fontWeight:700, color:"#fff",
                }}>{(user || "?")[0].toUpperCase()}</div>
                <div>
                  <div style={{ fontFamily:"'Barlow Condensed'", fontSize:14, color:G.text }}>
                    {user}
                  </div>
                  <div style={{ fontSize:10, color:G.muted, fontFamily:"'Share Tech Mono'" }}>
                    OPERATOR
                  </div>
                </div>
              </div>
            </div>

            <div style={{
              background:`${G.red}11`, border:`1px solid ${G.red}33`,
              borderRadius:8, padding:12, fontSize:11, color:G.muted,
            }}>
              ⚠️ Press <strong style={{ color:G.red }}>SOS</strong> only for genuine emergencies.
              All alerts are logged and reviewed by command.
            </div>
          </div>
        </div>
      )}

      {/* ── INBOX ── */}
      {tab === "inbox" && (
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <div style={{ display:"flex", gap:12 }}>
              {[
                { label:`OPEN (${openAlerts.length})`,         color:G.red    },
                { label:`ACKNOWLEDGED (${ackAlerts.length})`,  color:G.yellow },
                { label:`RESOLVED (${doneAlerts.length})`,     color:G.green  },
              ].map(({ label, color }) => (
                <div key={label} style={{
                  fontSize:10, fontFamily:"'Share Tech Mono'", color,
                  padding:"3px 8px", background:`${color}18`,
                  border:`1px solid ${color}44`, borderRadius:10,
                }}>{label}</div>
              ))}
            </div>
            <button onClick={fetchAlerts} style={{
              background:"none", border:`1px solid ${G.border}`,
              color:G.muted, cursor:"pointer", fontSize:11,
              fontFamily:"'Share Tech Mono'", padding:"4px 10px", borderRadius:4,
            }}>↻ REFRESH</button>
          </div>

          {loadingAlerts && (
            <div style={{ textAlign:"center", padding:24, color:G.muted }}>Loading...</div>
          )}

          {!loadingAlerts && alerts.length === 0 && (
            <div style={{ textAlign:"center", padding:"48px 0", color:G.muted }}>
              <div style={{ fontSize:36, marginBottom:10 }}>📭</div>
              <div style={{ fontFamily:"'Barlow Condensed'", fontSize:16, letterSpacing:2 }}>
                NO ALERTS
              </div>
            </div>
          )}

          {alerts.map(a => (
            <div key={a.id} className="slide-in" style={{
              background:G.card, border:`1px solid ${G.border}`,
              borderLeft:`4px solid ${SEV_COLOR[a.severity] || G.muted}`,
              borderRadius:8, padding:"14px 16px",
            }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
                <div style={{ display:"flex", gap:10, alignItems:"center" }}>
                  <span style={{
                    padding:"2px 8px", borderRadius:10, fontSize:10,
                    fontFamily:"'Share Tech Mono'", letterSpacing:1,
                    background:`${SEV_COLOR[a.severity]}22`,
                    color:SEV_COLOR[a.severity],
                    border:`1px solid ${SEV_COLOR[a.severity]}44`,
                  }}>{a.severity}</span>
                  <span style={{
                    padding:"2px 8px", borderRadius:10, fontSize:10,
                    fontFamily:"'Share Tech Mono'", letterSpacing:1,
                    background:`${STATUS_COLOR[a.status]}22`,
                    color:STATUS_COLOR[a.status],
                    border:`1px solid ${STATUS_COLOR[a.status]}44`,
                  }}>{a.status}</span>
                  <span style={{
                    fontFamily:"'Barlow Condensed'", fontWeight:700,
                    fontSize:13, color:G.text,
                  }}>{a.display_name || a.username}</span>
                </div>
                <span style={{ fontSize:10, color:G.muted, fontFamily:"'Share Tech Mono'" }}>
                  {a.created_at ? new Date(a.created_at).toLocaleString("en-IN") : ""}
                </span>
              </div>

              <div style={{ color:G.text, fontSize:13, marginBottom:8, lineHeight:1.5 }}>
                {a.message}
              </div>

              {(a.location_name || a.lat || a.latitude) && (
                <div style={{
                  fontSize:11, color:G.blue, fontFamily:"'Share Tech Mono'", marginBottom:8,
                }}>
                  📍 {a.location_name || `${a.latitude}, ${a.longitude}`}
                </div>
              )}

              {a.admin_note && (
                <div style={{
                  background:`${G.green}11`, border:`1px solid ${G.green}33`,
                  borderRadius:5, padding:"6px 10px", fontSize:11,
                  color:G.green, marginBottom:8, fontFamily:"'Share Tech Mono'",
                }}>
                  Admin note: {a.admin_note}
                </div>
              )}

              {a.status !== "RESOLVED" && (
                <div style={{ display:"flex", gap:8, marginTop:6 }}>
                  {a.status === "OPEN" && (
                    <button onClick={() => updateStatus(a.id, "ACKNOWLEDGED")} style={{
                      background:`${G.yellow}18`, border:`1px solid ${G.yellow}44`,
                      color:G.yellow, padding:"5px 12px", borderRadius:5,
                      cursor:"pointer", fontSize:11,
                      fontFamily:"'Barlow Condensed'", fontWeight:700, letterSpacing:1,
                    }}>✓ ACKNOWLEDGE</button>
                  )}
                  <button onClick={() => updateStatus(a.id, "RESOLVED", "Handled by command")} style={{
                    background:`${G.green}18`, border:`1px solid ${G.green}44`,
                    color:G.green, padding:"5px 12px", borderRadius:5,
                    cursor:"pointer", fontSize:11,
                    fontFamily:"'Barlow Condensed'", fontWeight:700, letterSpacing:1,
                  }}>✓ RESOLVE</button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// FEATURE — LIVE MAP (Leaflet.js)
// Disaster zones · safe zones · hospitals · rescue units · SOS pins
// ══════════════════════════════════════════════════════════════════════════

function LiveMap({ token }) {
  const mapRef      = useRef(null);
  const leafletRef  = useRef(null);
  const layersRef   = useRef({});
  const [mapData, setMapData]       = useState(null);
  const [sosPins, setSosPins]       = useState([]);
  const [layers, setLayers]         = useState({
    disasters:true, safeZones:true, hospitals:true,
    rescueUnits:true, sosPins:true,
  });
  const [loading, setLoading]       = useState(true);
  const [stats, setStats]           = useState(null);

  const headers = { Authorization: `Bearer ${localStorage.getItem("dc_token") || token || ""}` };

  // Fetch data
  useEffect(() => {
    Promise.all([
      fetch(`${API}/map/data`,    { headers }).then(r => r.json()),
      fetch(`${API}/map/sos-pins`,{ headers }).then(r => r.json()),
    ]).then(([md, sp]) => {
      setMapData(md);
      setSosPins(sp.pins || []);
      setStats({
        disasters:   md.disaster_zones?.length || 0,
        safeZones:   md.safe_zones?.length     || 0,
        hospitals:   md.hospitals?.length      || 0,
        rescueUnits: md.rescue_units?.length   || 0,
        sosPins:     sp.pins?.length           || 0,
      });
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  // Build map once data + container ready
  useEffect(() => {
    if (loading || !mapData || !mapRef.current) return;
    if (leafletRef.current) return; // already built

    const L = window.L;
    if (!L) return;

    // Init map centred on Bangalore
    const map = L.map(mapRef.current, {
      center: [12.9716, 77.5946],
      zoom: 12,
      zoomControl: true,
    });
    leafletRef.current = map;

    // Dark tile layer
    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
      attribution: '© OpenStreetMap contributors © CARTO',
      maxZoom: 19,
    }).addTo(map);

    // ── Disaster zones ──
    const disasterGroup = L.layerGroup().addTo(map);
    layersRef.current.disasters = disasterGroup;
    const disasterColors = {
      flood:"#38bdf8", fire:"#f97316", earthquake:"#eab308",
      chemical_spill:"#a855f7", building_collapse:"#ef4444",
    };
    const disasterIcons = {
      flood:"🌊", fire:"🔥", earthquake:"⚡", chemical_spill:"☣️", building_collapse:"🏚️",
    };
    (mapData.disaster_zones || []).forEach(dz => {
      const col = disasterColors[dz.type] || "#ef4444";
      // Radius circle
      L.circle([dz.lat, dz.lng], {
        radius: dz.radius,
        color: col, fillColor: col,
        fillOpacity: 0.12, weight: 2, opacity: 0.7,
        dashArray: "6 4",
      }).addTo(disasterGroup);
      // Icon marker
      const icon = L.divIcon({
        className:"",
        html:`<div style="
          background:${col}22;border:2px solid ${col};
          border-radius:50%;width:36px;height:36px;
          display:flex;align-items:center;justify-content:center;
          font-size:18px;box-shadow:0 0 12px ${col}66;
          backdrop-filter:blur(2px);
        ">${disasterIcons[dz.type]||"⚠️"}</div>`,
        iconSize:[36,36], iconAnchor:[18,18],
      });
      L.marker([dz.lat, dz.lng], { icon })
        .bindPopup(`
          <div style="font-family:'Barlow',sans-serif;min-width:180px;">
            <div style="font-weight:700;font-size:14px;margin-bottom:6px;">${dz.name}</div>
            <div style="color:#888;font-size:12px;">Type: <span style="color:${col}">${dz.type.replace("_"," ")}</span></div>
            <div style="color:#888;font-size:12px;">Severity: <span style="color:${col}">${dz.severity}</span></div>
            <div style="color:#888;font-size:12px;">Radius: ${dz.radius}m</div>
          </div>`)
        .addTo(disasterGroup);
    });

    // ── Safe zones ──
    const safeGroup = L.layerGroup().addTo(map);
    layersRef.current.safeZones = safeGroup;
    (mapData.safe_zones || []).forEach(sz => {
      const col = sz.status === "open" ? "#22c55e" : "#eab308";
      const icon = L.divIcon({
        className:"",
        html:`<div style="
          background:${col}22;border:2px solid ${col};
          border-radius:8px;width:32px;height:32px;
          display:flex;align-items:center;justify-content:center;
          font-size:16px;box-shadow:0 0 8px ${col}55;
        ">🏕️</div>`,
        iconSize:[32,32], iconAnchor:[16,16],
      });
      L.marker([sz.lat, sz.lng], { icon })
        .bindPopup(`
          <div style="font-family:'Barlow',sans-serif;min-width:160px;">
            <div style="font-weight:700;font-size:14px;margin-bottom:4px;">${sz.name}</div>
            <div style="color:#888;font-size:12px;">Capacity: <strong>${sz.capacity}</strong> people</div>
            <div style="color:#888;font-size:12px;">Status: <span style="color:${col};font-weight:700;text-transform:uppercase">${sz.status}</span></div>
          </div>`)
        .addTo(safeGroup);
    });

    // ── Hospitals ──
    const hospGroup = L.layerGroup().addTo(map);
    layersRef.current.hospitals = hospGroup;
    (mapData.hospitals || []).forEach(h => {
      const col = h.emergency ? "#ef4444" : "#64748b";
      const icon = L.divIcon({
        className:"",
        html:`<div style="
          background:${col}22;border:2px solid ${col};
          border-radius:50%;width:34px;height:34px;
          display:flex;align-items:center;justify-content:center;
          font-size:16px;box-shadow:0 0 10px ${col}55;
          font-weight:700;color:${col};font-family:monospace;font-size:18px;
        ">🏥</div>`,
        iconSize:[34,34], iconAnchor:[17,17],
      });
      L.marker([h.lat, h.lng], { icon })
        .bindPopup(`
          <div style="font-family:'Barlow',sans-serif;min-width:160px;">
            <div style="font-weight:700;font-size:14px;margin-bottom:4px;">${h.name}</div>
            <div style="color:#888;font-size:12px;">Beds: <strong>${h.beds}</strong></div>
            <div style="color:#888;font-size:12px;">Emergency: <span style="color:${col};font-weight:700">${h.emergency ? "YES" : "NO"}</span></div>
          </div>`)
        .addTo(hospGroup);
    });

    // ── Rescue units ──
    const rescueGroup = L.layerGroup().addTo(map);
    layersRef.current.rescueUnits = rescueGroup;
    const rescueIcons2 = { ambulance:"🚑", fire_truck:"🚒", rescue_team:"⛑️", helicopter:"🚁" };
    (mapData.rescue_units || []).forEach(ru => {
      const icon = L.divIcon({
        className:"",
        html:`<div style="
          background:#1a2235;border:2px solid #38bdf8;
          border-radius:6px;width:30px;height:30px;
          display:flex;align-items:center;justify-content:center;font-size:15px;
        ">${rescueIcons2[ru.type]||"🚨"}</div>`,
        iconSize:[30,30], iconAnchor:[15,15],
      });
      L.marker([ru.lat, ru.lng], { icon })
        .bindPopup(`
          <div style="font-family:'Barlow',sans-serif;min-width:140px;">
            <div style="font-weight:700;font-size:14px;margin-bottom:4px;">${ru.name}</div>
            <div style="color:#888;font-size:12px;">Type: ${ru.type.replace("_"," ")}</div>
            <div style="color:#22c55e;font-size:12px;font-weight:700">Available: ${ru.available}</div>
          </div>`)
        .addTo(rescueGroup);
    });

    // ── SOS pins ──
    const sosGroup = L.layerGroup().addTo(map);
    layersRef.current.sosPins = sosGroup;
    sosPins.forEach(pin => {
      if (!pin.lat || !pin.lng) return;
      const icon = L.divIcon({
        className:"",
        html:`<div style="
          background:#ef444422;border:3px solid #ef4444;
          border-radius:50%;width:38px;height:38px;
          display:flex;align-items:center;justify-content:center;
          font-size:18px;animation:mapPing 1.4s ease-out infinite;
          box-shadow:0 0 16px #ef444488;
        ">🆘</div>`,
        iconSize:[38,38], iconAnchor:[19,19],
      });
      L.marker([pin.lat, pin.lng], { icon })
        .bindPopup(`
          <div style="font-family:'Barlow',sans-serif;min-width:180px;">
            <div style="color:#ef4444;font-weight:700;font-size:14px;margin-bottom:4px;">🆘 SOS ALERT</div>
            <div style="font-weight:600;margin-bottom:4px;">${pin.username}</div>
            <div style="color:#888;font-size:12px;margin-bottom:4px;">${pin.message}</div>
            <div style="color:#ef4444;font-size:11px;font-weight:700">${pin.severity}</div>
            ${pin.location_name ? `<div style="color:#888;font-size:11px;">📍 ${pin.location_name}</div>` : ""}
          </div>`)
        .addTo(sosGroup);
    });

  }, [loading, mapData, sosPins]);

  // Toggle layer visibility
  useEffect(() => {
    const L = window.L;
    const map = leafletRef.current;
    if (!L || !map) return;
    Object.entries(layers).forEach(([key, visible]) => {
      const camelMap = {
        disasters:"disasters", safeZones:"safeZones",
        hospitals:"hospitals", rescueUnits:"rescueUnits", sosPins:"sosPins",
      };
      const group = layersRef.current[camelMap[key]];
      if (!group) return;
      if (visible) map.addLayer(group);
      else         map.removeLayer(group);
    });
  }, [layers]);

  const toggleLayer = (key) =>
    setLayers(prev => ({ ...prev, [key]: !prev[key] }));

  const LAYER_DEFS = [
    { key:"disasters",   label:"Disaster Zones", icon:"⚠️",  color:G.red    },
    { key:"safeZones",   label:"Safe Zones",     icon:"🏕️",  color:G.green  },
    { key:"hospitals",   label:"Hospitals",      icon:"🏥",  color:G.accent },
    { key:"rescueUnits", label:"Rescue Units",   icon:"🚑",  color:G.blue   },
    { key:"sosPins",     label:"SOS Alerts",     icon:"🆘",  color:G.red    },
  ];

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:12 }}>

      {/* Stats bar */}
      {stats && (
        <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
          {[
            { label:"Disaster Zones", val:stats.disasters,   color:G.red    },
            { label:"Safe Zones",     val:stats.safeZones,   color:G.green  },
            { label:"Hospitals",      val:stats.hospitals,   color:G.accent },
            { label:"Rescue Units",   val:stats.rescueUnits, color:G.blue   },
            { label:"SOS Active",     val:stats.sosPins,     color:G.red    },
          ].map(({ label, val, color }) => (
            <div key={label} style={{
              background:G.card, border:`1px solid ${G.border}`,
              borderTop:`3px solid ${color}`,
              borderRadius:8, padding:"10px 16px", flex:1, minWidth:100,
            }}>
              <div style={{ fontSize:10, color:G.muted, letterSpacing:1, marginBottom:2 }}>
                {label.toUpperCase()}
              </div>
              <div style={{
                fontFamily:"'Barlow Condensed'", fontSize:28,
                fontWeight:700, color, lineHeight:1,
              }}>{val}</div>
            </div>
          ))}
        </div>
      )}

      {/* Layer toggles */}
      <div style={{
        display:"flex", gap:8, flexWrap:"wrap",
        background:G.grid, borderRadius:8, padding:"10px 14px",
        alignItems:"center",
      }}>
        <span style={{
          fontFamily:"'Barlow Condensed'", fontWeight:700,
          fontSize:11, letterSpacing:2, color:G.muted, marginRight:4,
        }}>LAYERS:</span>
        {LAYER_DEFS.map(({ key, label, icon, color }) => (
          <button key={key} onClick={() => toggleLayer(key)} style={{
            padding:"5px 12px",
            background: layers[key] ? `${color}22` : G.card,
            border: `1px solid ${layers[key] ? color : G.border}`,
            borderRadius:20, cursor:"pointer",
            fontFamily:"'Barlow Condensed'", fontWeight:700,
            fontSize:11, letterSpacing:1,
            color: layers[key] ? color : G.muted,
            transition:"all 0.15s",
            display:"flex", alignItems:"center", gap:5,
          }}>
            <span style={{ fontSize:13 }}>{icon}</span> {label}
          </button>
        ))}
      </div>

      {/* Map container */}
      <div style={{
        position:"relative", borderRadius:12, overflow:"hidden",
        border:`1px solid ${G.border}`, height:520,
      }}>
        {loading && (
          <div style={{
            position:"absolute", inset:0, zIndex:999,
            background:G.card, display:"flex",
            alignItems:"center", justifyContent:"center",
            flexDirection:"column", gap:12,
          }}>
            <div style={{
              width:32, height:32, border:`3px solid ${G.accent}`,
              borderTopColor:"transparent", borderRadius:"50%",
              animation:"spin 0.8s linear infinite",
            }} />
            <div style={{ fontFamily:"'Share Tech Mono'", fontSize:12, color:G.muted }}>
              LOADING MAP DATA...
            </div>
          </div>
        )}
        <div ref={mapRef} style={{ width:"100%", height:"100%" }} />
      </div>

      <div style={{ fontSize:10, color:G.muted, fontFamily:"'Share Tech Mono'" }}>
        MAP DATA: BANGALORE REGION · CLICK ANY MARKER FOR DETAILS · TOGGLE LAYERS ABOVE
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// FEATURE 1 — CHARTS OVER TIME
// Line + bar chart of save rates / lives saved across all runs this session.
// ══════════════════════════════════════════════════════════════════════════

function RunHistoryChart({ history }) {
  if (history.length === 0) {
    return (
      <div style={{
        textAlign:"center", padding:"60px 0", color:G.muted,
      }}>
        <div style={{ fontSize:40, marginBottom:12 }}>📈</div>
        <div style={{ fontFamily:"'Barlow Condensed'", fontSize:18, letterSpacing:2 }}>
          NO RUNS YET
        </div>
        <div style={{ fontSize:12, marginTop:6 }}>
          Run a simulation — charts appear automatically
        </div>
      </div>
    );
  }

  const W = 700, H = 260, PAD = { top:20, right:20, bottom:48, left:52 };
  const innerW = W - PAD.left - PAD.right;
  const innerH = H - PAD.top  - PAD.bottom;

  const maxSaveRate  = 100;
  const maxLives     = Math.max(...history.map(r => r.livesAtRisk), 1);

  // X positions
  const xOf = (i) => PAD.left + (i / Math.max(history.length - 1, 1)) * innerW;
  const yRate = (v) => PAD.top + innerH - (v / maxSaveRate) * innerH;
  const yLives = (v) => PAD.top + innerH - (v / maxLives) * innerH;

  // Save-rate polyline
  const ratePoints = history.map((r, i) => `${xOf(i)},${yRate(r.saveRate)}`).join(" ");
  // Lives saved bars
  const barW = Math.min(innerW / history.length * 0.5, 28);

  // Y-axis grid lines (save rate, left axis)
  const gridLines = [0, 25, 50, 75, 100];

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
      {/* Legend */}
      <div style={{ display:"flex", gap:20, alignItems:"center" }}>
        <div style={{ display:"flex", alignItems:"center", gap:6 }}>
          <div style={{ width:24, height:3, background:G.blue, borderRadius:2 }} />
          <span style={{ fontSize:11, color:G.muted, fontFamily:"'Share Tech Mono'" }}>AVG SAVE RATE %</span>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:6 }}>
          <div style={{ width:12, height:12, background:`${G.green}88`, borderRadius:2 }} />
          <span style={{ fontSize:11, color:G.muted, fontFamily:"'Share Tech Mono'" }}>LIVES SAVED</span>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:6 }}>
          <div style={{ width:12, height:12, background:`${G.muted}44`, borderRadius:2 }} />
          <span style={{ fontSize:11, color:G.muted, fontFamily:"'Share Tech Mono'" }}>LIVES AT RISK</span>
        </div>
        <div style={{ marginLeft:"auto", fontFamily:"'Share Tech Mono'", fontSize:11, color:G.muted }}>
          {history.length} RUN{history.length !== 1 ? "S" : ""}
        </div>
      </div>

      {/* SVG chart */}
      <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ overflow:"visible" }}>
        {/* Grid lines + Y labels */}
        {gridLines.map(v => (
          <g key={v}>
            <line
              x1={PAD.left} y1={yRate(v)} x2={PAD.left + innerW} y2={yRate(v)}
              stroke={G.border} strokeWidth={0.5} strokeDasharray="4 4"
            />
            <text x={PAD.left - 6} y={yRate(v) + 4}
              textAnchor="end" fontSize={10}
              fontFamily="'Share Tech Mono'" fill={G.muted}>{v}%</text>
          </g>
        ))}

        {/* Bars — lives at risk (background) */}
        {history.map((r, i) => (
          <rect key={`risk-${i}`}
            x={xOf(i) - barW / 2} y={yLives(r.livesAtRisk)}
            width={barW} height={innerH - (yLives(r.livesAtRisk) - PAD.top)}
            fill={`${G.muted}33`} rx={2}
          />
        ))}

        {/* Bars — lives saved (foreground) */}
        {history.map((r, i) => (
          <rect key={`saved-${i}`}
            x={xOf(i) - barW / 2} y={yLives(r.livesSaved)}
            width={barW} height={innerH - (yLives(r.livesSaved) - PAD.top)}
            fill={`${G.green}88`} rx={2}
          />
        ))}

        {/* Save-rate line area fill */}
        {history.length > 1 && (
          <polyline
            points={[
              `${xOf(0)},${PAD.top + innerH}`,
              ...history.map((r, i) => `${xOf(i)},${yRate(r.saveRate)}`),
              `${xOf(history.length - 1)},${PAD.top + innerH}`,
            ].join(" ")}
            fill={`${G.blue}18`} stroke="none"
          />
        )}

        {/* Save-rate line */}
        {history.length > 1 && (
          <polyline
            points={ratePoints}
            fill="none" stroke={G.blue} strokeWidth={2}
            strokeLinejoin="round" strokeLinecap="round"
          />
        )}

        {/* Dots on save-rate line */}
        {history.map((r, i) => (
          <g key={`dot-${i}`}>
            <circle cx={xOf(i)} cy={yRate(r.saveRate)} r={4}
              fill={G.bg} stroke={G.blue} strokeWidth={2} />
            {/* Tooltip on hover via title */}
            <title>{r.scenario} · {r.saveRate}% save rate · {r.livesSaved}/{r.livesAtRisk} lives</title>
          </g>
        ))}

        {/* X axis labels */}
        {history.map((r, i) => (
          <text key={`xl-${i}`}
            x={xOf(i)} y={H - 8}
            textAnchor="middle" fontSize={9}
            fontFamily="'Share Tech Mono'" fill={G.muted}>
            #{i + 1}
          </text>
        ))}

        {/* X axis baseline */}
        <line
          x1={PAD.left} y1={PAD.top + innerH}
          x2={PAD.left + innerW} y2={PAD.top + innerH}
          stroke={G.border} strokeWidth={1}
        />

        {/* Y axis baseline */}
        <line
          x1={PAD.left} y1={PAD.top}
          x2={PAD.left} y2={PAD.top + innerH}
          stroke={G.border} strokeWidth={1}
        />
      </svg>

      {/* Run table */}
      <div style={{ overflowX:"auto" }}>
        <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12 }}>
          <thead>
            <tr style={{ borderBottom:`1px solid ${G.border}` }}>
              {["Run","Scenario","Events","Save Rate","Lives Saved","Lives at Risk","vs Baseline","Success"].map(h => (
                <th key={h} style={{
                  padding:"6px 10px", textAlign:"left",
                  color:G.muted, fontFamily:"'Barlow Condensed'",
                  fontWeight:700, letterSpacing:1, fontSize:11,
                }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {history.map((r, i) => (
              <tr key={i} style={{ borderBottom:`1px solid ${G.border}22` }}>
                <td style={{ padding:"7px 10px", fontFamily:"'Share Tech Mono'", color:G.muted }}>
                  #{i + 1}
                </td>
                <td style={{ padding:"7px 10px", color:G.text, maxWidth:180,
                  overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                  {r.scenario}
                </td>
                <td style={{ padding:"7px 10px", fontFamily:"'Share Tech Mono'" }}>{r.events}</td>
                <td style={{ padding:"7px 10px", fontFamily:"'Share Tech Mono'",
                  color: r.saveRate >= 80 ? G.green : r.saveRate >= 60 ? G.yellow : G.accent }}>
                  {r.saveRate}%
                </td>
                <td style={{ padding:"7px 10px", fontFamily:"'Share Tech Mono'", color:G.green }}>
                  {r.livesSaved}
                </td>
                <td style={{ padding:"7px 10px", fontFamily:"'Share Tech Mono'" }}>{r.livesAtRisk}</td>
                <td style={{ padding:"7px 10px", fontFamily:"'Share Tech Mono'",
                  color: r.improvement >= 0 ? G.green : G.red }}>
                  {r.improvement >= 0 ? "+" : ""}{r.improvement}
                </td>
                <td style={{ padding:"7px 10px" }}>
                  <span style={{
                    padding:"2px 8px", borderRadius:10, fontSize:10,
                    background: r.successRate >= 50 ? `${G.green}22` : `${G.red}22`,
                    color: r.successRate >= 50 ? G.green : G.red,
                  }}>{r.successRate}%</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// FEATURE 2 — AGENT COMMUNICATION GRAPH
// Interactive SVG node diagram showing message counts between agents.
// ══════════════════════════════════════════════════════════════════════════

function AgentCommGraph({ messages }) {
  const [hoveredEdge, setHoveredEdge] = useState(null);
  const [hoveredNode, setHoveredNode] = useState(null);

  if (!messages || messages.length === 0) {
    return (
      <div style={{ textAlign:"center", padding:"60px 0", color:G.muted }}>
        <div style={{ fontSize:40, marginBottom:12 }}>🕸️</div>
        <div style={{ fontFamily:"'Barlow Condensed'", fontSize:18, letterSpacing:2 }}>
          NO DATA YET
        </div>
        <div style={{ fontSize:12, marginTop:6 }}>Run a simulation to see the communication graph</div>
      </div>
    );
  }

  // Node positions (fixed layout, centred in 600×340 canvas)
  const NODES = {
    MonitorAgent:        { x:110, y:170, label:"MONITOR",   icon:"📡", color:G.blue   },
    ResourceAllocator:   { x:270, y: 60, label:"ALLOCATOR", icon:"⚙️", color:G.yellow },
    RescueCoordinator:   { x:430, y:170, label:"RESCUE",    icon:"🚁", color:G.green  },
    EvaluatorAgent:      { x:270, y:280, label:"EVALUATOR", icon:"📊", color:G.purple },
  };
  const NODE_R = 46;

  // Count messages per sender→receiver pair and per type
  const edgeCounts = {};
  const edgeTypes  = {};
  const nodeSent   = {};
  const nodeRecv   = {};

  messages.forEach(m => {
    const s = m.sender;
    const r = m.receiver;
    if (!NODES[s] || !NODES[r]) return;
    const key = `${s}→${r}`;
    edgeCounts[key] = (edgeCounts[key] || 0) + 1;
    if (!edgeTypes[key]) edgeTypes[key] = {};
    edgeTypes[key][m.msg_type] = (edgeTypes[key][m.msg_type] || 0) + 1;
    nodeSent[s] = (nodeSent[s] || 0) + 1;
    nodeRecv[r] = (nodeRecv[r] || 0) + 1;
  });

  const maxEdge = Math.max(...Object.values(edgeCounts), 1);

  // Draw a curved arrow between two nodes
  function EdgeArrow({ from, to, edgeKey }) {
    const a = NODES[from], b = NODES[to];
    if (!a || !b) return null;
    const count = edgeCounts[edgeKey] || 0;
    if (count === 0) return null;

    const isHovered = hoveredEdge === edgeKey;
    const strokeW   = 1 + (count / maxEdge) * 4;
    const color     = NODES[from].color;
    const alpha     = isHovered ? "ff" : "99";

    // midpoint offset for curve — perpendicular to the line
    const dx  = b.x - a.x, dy  = b.y - a.y;
    const len = Math.sqrt(dx * dx + dy * dy);
    const mx  = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    const ox  = (-dy / len) * 30, oy = (dx / len) * 30;
    const cx  = mx + ox, cy = my + oy;

    // Arrow endpoint — stop at node radius
    const ex = b.x - (dx / len) * (NODE_R + 6);
    const ey = b.y - (dy / len) * (NODE_R + 6);
    const sx = a.x + (dx / len) * (NODE_R + 2);
    const sy = a.y + (dy / len) * (NODE_R + 2);

    // label position at curve midpoint
    const lx = 0.25 * sx + 0.5 * cx + 0.25 * ex;
    const ly = 0.25 * sy + 0.5 * cy + 0.25 * ey;

    const types = edgeTypes[edgeKey] || {};

    return (
      <g
        style={{ cursor:"pointer" }}
        onMouseEnter={() => setHoveredEdge(edgeKey)}
        onMouseLeave={() => setHoveredEdge(null)}
      >
        {/* Hit area */}
        <path d={`M${sx},${sy} Q${cx},${cy} ${ex},${ey}`}
          fill="none" stroke="transparent" strokeWidth={16} />
        {/* Visible arc */}
        <path d={`M${sx},${sy} Q${cx},${cy} ${ex},${ey}`}
          fill="none"
          stroke={color + alpha}
          strokeWidth={isHovered ? strokeW + 1 : strokeW}
          strokeLinecap="round"
          markerEnd={`url(#arr-${from.slice(0,3)})`}
        />
        {/* Count badge */}
        <circle cx={lx} cy={ly} r={10}
          fill={G.card} stroke={color + "88"} strokeWidth={1} />
        <text x={lx} y={ly + 4} textAnchor="middle"
          fontSize={9} fontFamily="'Share Tech Mono'" fill={color}>
          {count}
        </text>

        {/* Tooltip on hover */}
        {isHovered && (
          <g>
            <rect x={lx - 70} y={ly + 14} width={140} height={14 * Object.keys(types).length + 10}
              rx={4} fill={G.surface} stroke={G.border} strokeWidth={1} />
            {Object.entries(types).map(([type, cnt], i) => (
              <text key={type}
                x={lx - 62} y={ly + 26 + i * 14}
                fontSize={9} fontFamily="'Share Tech Mono'" fill={G.muted}>
                {type.slice(0,20)}: {cnt}
              </text>
            ))}
          </g>
        )}
      </g>
    );
  }

  const allEdges = [
    ["MonitorAgent",      "ResourceAllocator", "MonitorAgent→ResourceAllocator"],
    ["ResourceAllocator", "RescueCoordinator", "ResourceAllocator→RescueCoordinator"],
    ["RescueCoordinator", "EvaluatorAgent",    "RescueCoordinator→EvaluatorAgent"],
    ["MonitorAgent",      "RescueCoordinator", "MonitorAgent→RescueCoordinator"],
  ];

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
      <div style={{ display:"flex", gap:16, alignItems:"flex-start" }}>
        {/* Graph */}
        <div style={{ flex:1, background:G.grid, borderRadius:8, padding:16 }}>
          <svg width="100%" viewBox="0 0 560 360" style={{ overflow:"visible" }}>
            <defs>
              {Object.entries(NODES).map(([name, n]) => (
                <marker key={name}
                  id={`arr-${name.slice(0,3)}`}
                  viewBox="0 0 10 10" refX="8" refY="5"
                  markerWidth={5} markerHeight={5} orient="auto-start-reverse">
                  <path d="M2 1L8 5L2 9" fill="none"
                    stroke={n.color} strokeWidth={1.5}
                    strokeLinecap="round" strokeLinejoin="round" />
                </marker>
              ))}
            </defs>

            {/* Edges */}
            {allEdges.map(([from, to, key]) => (
              <EdgeArrow key={key} from={from} to={to} edgeKey={key} />
            ))}

            {/* Nodes */}
            {Object.entries(NODES).map(([name, n]) => {
              const isHov  = hoveredNode === name;
              const sent   = nodeSent[name] || 0;
              const recv   = nodeRecv[name] || 0;
              const total  = sent + recv;
              return (
                <g key={name}
                  style={{ cursor:"pointer" }}
                  onMouseEnter={() => setHoveredNode(name)}
                  onMouseLeave={() => setHoveredNode(null)}>
                  {/* Glow ring */}
                  <circle cx={n.x} cy={n.y} r={NODE_R + 6}
                    fill="none"
                    stroke={n.color}
                    strokeWidth={isHov ? 2 : 0.5}
                    opacity={isHov ? 0.6 : 0.2}
                  />
                  {/* Main circle */}
                  <circle cx={n.x} cy={n.y} r={NODE_R}
                    fill={G.card}
                    stroke={n.color}
                    strokeWidth={isHov ? 2 : 1}
                  />
                  {/* Icon */}
                  <text x={n.x} y={n.y - 10} textAnchor="middle"
                    fontSize={20} dominantBaseline="central">
                    {n.icon}
                  </text>
                  {/* Label */}
                  <text x={n.x} y={n.y + 12} textAnchor="middle"
                    fontSize={10} fontFamily="'Barlow Condensed'"
                    fontWeight={700} letterSpacing={1} fill={n.color}>
                    {n.label}
                  </text>
                  {/* Message count */}
                  <text x={n.x} y={n.y + 26} textAnchor="middle"
                    fontSize={9} fontFamily="'Share Tech Mono'" fill={G.muted}>
                    {total} msg
                  </text>

                  {/* Hover stats */}
                  {isHov && (
                    <g>
                      <rect x={n.x - 50} y={n.y + NODE_R + 8} width={100} height={36}
                        rx={4} fill={G.surface} stroke={n.color + "66"} strokeWidth={1} />
                      <text x={n.x} y={n.y + NODE_R + 22}
                        textAnchor="middle" fontSize={9}
                        fontFamily="'Share Tech Mono'" fill={G.green}>
                        ↑ sent {sent}
                      </text>
                      <text x={n.x} y={n.y + NODE_R + 36}
                        textAnchor="middle" fontSize={9}
                        fontFamily="'Share Tech Mono'" fill={G.blue}>
                        ↓ recv {recv}
                      </text>
                    </g>
                  )}
                </g>
              );
            })}
          </svg>
        </div>

        {/* Stats sidebar */}
        <div style={{ width:180, display:"flex", flexDirection:"column", gap:10 }}>
          <div style={{
            fontFamily:"'Barlow Condensed'", fontWeight:700,
            letterSpacing:2, fontSize:11, color:G.muted, marginBottom:4,
          }}>MESSAGE STATS</div>

          {Object.entries(NODES).map(([name, n]) => {
            const sent  = nodeSent[name]  || 0;
            const recv  = nodeRecv[name]  || 0;
            const total = sent + recv;
            const pct   = Math.round((total / Math.max(messages.length * 2, 1)) * 100);
            return (
              <div key={name} style={{
                background:G.card, border:`1px solid ${G.border}`,
                borderLeft:`3px solid ${n.color}`,
                borderRadius:6, padding:"8px 10px",
              }}>
                <div style={{
                  fontFamily:"'Barlow Condensed'", fontWeight:700,
                  fontSize:12, color:n.color, letterSpacing:1,
                }}>{n.label}</div>
                <div style={{
                  display:"flex", justifyContent:"space-between",
                  marginTop:4, fontSize:10,
                  fontFamily:"'Share Tech Mono'", color:G.muted,
                }}>
                  <span>↑ {sent}</span>
                  <span>↓ {recv}</span>
                  <span style={{ color:n.color }}>{pct}%</span>
                </div>
                <div style={{
                  marginTop:5, height:3, background:G.border, borderRadius:2,
                }}>
                  <div style={{
                    width:`${pct}%`, height:"100%",
                    background:n.color, borderRadius:2, transition:"width 0.4s",
                  }} />
                </div>
              </div>
            );
          })}

          <div style={{
            background:G.card, border:`1px solid ${G.border}`,
            borderRadius:6, padding:"8px 10px", marginTop:4,
          }}>
            <div style={{
              fontFamily:"'Barlow Condensed'", fontWeight:700,
              fontSize:11, color:G.muted, letterSpacing:1, marginBottom:6,
            }}>MSG TYPES</div>
            {[...new Set(messages.map(m => m.msg_type))].map(t => {
              const cnt = messages.filter(m => m.msg_type === t).length;
              return (
                <div key={t} style={{
                  display:"flex", justifyContent:"space-between",
                  fontSize:9, fontFamily:"'Share Tech Mono'",
                  color:G.muted, marginBottom:3,
                }}>
                  <span style={{ overflow:"hidden", textOverflow:"ellipsis", maxWidth:100 }}>
                    {t}
                  </span>
                  <span style={{ color:G.accent }}>{cnt}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div style={{ fontSize:11, color:G.muted, fontFamily:"'Share Tech Mono'" }}>
        HOVER over nodes or edges to see details · edge thickness = message volume
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// DASHBOARD
// ══════════════════════════════════════════════════════════════════════════

function Dashboard({ token, user, onLogout }) {
  const [scenarios, setScenarios]             = useState([]);
  const [selectedScenario, setSelectedScenario] = useState(1);
  const [seed, setSeed]                       = useState(42);
  const [running, setRunning]                 = useState(false);
  const [result, setResult]                   = useState(null);
  const [error, setError]                     = useState(null);
  const [tab, setTab]                         = useState("dashboard");
  const [activeAgent, setActiveAgent]         = useState(null);
  const [visMessages, setVisMessages]         = useState([]);
  const [visTransitions, setVisTransitions]   = useState([]);
  const [visAgentLog, setVisAgentLog]         = useState([]);
  const [visState, setVisState]               = useState("IDLE");
  const [runHistory, setRunHistory]           = useState([]);

  // Read token directly from localStorage on every request — always fresh, no stale closure possible
  const getHeaders = () => {
    const tok = localStorage.getItem("dc_token") || token || "";
    return {
      "Content-Type": "application/json",
      Authorization: `Bearer ${tok}`,
    };
  };

  // Wrapper around fetch that auto-logs out on 401 (stale/invalid token)
  const authFetch = async (url, opts = {}) => {
    const res = await fetch(url, { ...opts, headers: { ...getHeaders(), ...(opts.headers||{}) } });
    if (res.status === 401) {
      console.warn("[authFetch] 401 received — clearing stale token and redirecting to login");
      localStorage.removeItem("dc_token");
      localStorage.removeItem("dc_user");
      onLogout();
    }
    return res;
  };

  useEffect(() => {
    if (!localStorage.getItem("dc_token") && !token) return;
    authFetch(`${API}/scenarios`)
      .then(r => r.ok ? r.json() : null)
      .then(d => d && setScenarios(d.scenarios || []))
      .catch(() => {});
  }, [token]);

  const streamResults = useCallback((res) => {
    const msgs  = res.messages    || [];
    const trans = res.transitions || [];
    const agents = res.agent_log  || [];
    setVisMessages([]); setVisTransitions([]); setVisAgentLog([]); setVisState("IDLE");
    trans.forEach((t, i)  => setTimeout(() => {
      setVisTransitions(p => [...p, t]); setVisState(t.to_state);
    }, i * 400));
    agents.forEach((l, i) => setTimeout(() => {
      setVisAgentLog(p => [...p, l]); setActiveAgent(l.agent);
    }, i * 350 + 200));
    msgs.forEach((m, i)   => setTimeout(() => {
      setVisMessages(p => [...p, m]);
    }, i * 300 + 500));
    const total = Math.max(trans.length * 400, agents.length * 350, msgs.length * 300) + 1000;
    setTimeout(() => setActiveAgent(null), total);
  }, []);

  const handleRun = async () => {
    setRunning(true); setError(null); setResult(null);
    setVisMessages([]); setVisTransitions([]); setVisAgentLog([]); setVisState("MONITORING");
    try {
      const res = await authFetch(`${API}/run`, {
        method: "POST",
        body: JSON.stringify({ scenario_id: selectedScenario, seed: parseInt(seed) || 42 }),
      });
      if (!res.ok) { const e = await res.json(); throw new Error(e.detail || "Server error"); }
      const data = await res.json();
      setResult(data); streamResults(data);
      const m = data.metrics || {};
      setRunHistory(prev => [...prev, {
        scenario:    data.scenario?.name || `Scenario ${selectedScenario}`,
        events:      m.total_events      || 0,
        saveRate:    m.avg_save_rate      || 0,
        livesSaved:  m.total_lives_saved  || 0,
        livesAtRisk: m.total_lives_at_risk || 0,
        improvement: m.lives_saved_improvement ?? 0,
        successRate: m.success_rate       || 0,
      }]);
    } catch (e) { setError(e.message); }
    finally { setRunning(false); }
  };

  const handleReset = () => {
    setResult(null); setVisMessages([]); setVisTransitions([]);
    setVisAgentLog([]); setVisState("IDLE"); setActiveAgent(null); setError(null);
  };

  const handleLogout = async () => {
    try { await fetch(`${API}/auth/logout`, { method:"POST", headers: getHeaders() }); } catch {}
    onLogout();
  };

  const metrics      = result?.metrics || {};
  const eventsDetail = metrics.events_detail || [];
  const resources    = result?.resources || [];
  const mapEvents    = result?.scenario?.events?.map((ev, i) => ({ id:`ev-${i}`, ...ev })) || [];

  const TABS = [
    { id:"dashboard", label:"Dashboard"   },
    { id:"map",       label:"Map View"    },
    { id:"messages",  label:"Messages"    },
    { id:"agents",    label:"Agent Log"   },
    { id:"charts",    label:"Charts"      },
    { id:"commgraph", label:"Comm Graph"  },
    { id:"livemap",   label:"🗺 Live Map" },
    { id:"sos",       label:"🆘 SOS"      },
    { id:"builder",   label:"⚙ Build"    },
  ];

  const handleBuilderRun = useCallback((data, name) => {
    setResult(data); streamResults(data);
    const m = data.metrics || {};
    setRunHistory(prev => [...prev, {
      scenario:    name || "Custom Run",
      events:      m.total_events        || 0,
      saveRate:    m.avg_save_rate        || 0,
      livesSaved:  m.total_lives_saved    || 0,
      livesAtRisk: m.total_lives_at_risk  || 0,
      improvement: m.lives_saved_improvement ?? 0,
      successRate: m.success_rate         || 0,
    }]);
    setTab("dashboard");
  }, [streamResults]);

  return (
    <>
      {/* Header */}
      <div style={{
        background:G.surface, borderBottom:`2px solid ${G.border}`,
        padding:"0 24px", display:"flex", alignItems:"center",
        justifyContent:"space-between", height:56,
      }}>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <span style={{ fontSize:22 }}>🚨</span>
          <div>
            <div style={{
              fontFamily:"'Barlow Condensed'", fontWeight:700,
              fontSize:18, letterSpacing:2, color:G.accent,
            }}>DISASTER COMMAND</div>
            <div style={{
              fontSize:10, color:G.muted,
              fontFamily:"'Share Tech Mono'", letterSpacing:1,
            }}>MULTI-AGENT SIMULATION SYSTEM</div>
          </div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:16 }}>
          <StateBadge state={visState} />
          {result && (
            <div style={{ fontFamily:"'Share Tech Mono'", fontSize:10, color:G.muted }}>
              RUN: {result.run_id} · SEED: {result.seed}
            </div>
          )}
          {/* User badge */}
          <div style={{
            display:"flex", alignItems:"center", gap:10,
            padding:"4px 12px", background:G.card,
            border:`1px solid ${G.border}`, borderRadius:20,
          }}>
            <div style={{
              width:24, height:24, borderRadius:"50%", background:G.accent,
              display:"flex", alignItems:"center", justifyContent:"center",
              fontSize:11, fontWeight:700, color:"#fff",
            }}>{(user || "?")[0].toUpperCase()}</div>
            <span style={{ fontFamily:"'Barlow Condensed'", fontSize:13, color:G.text }}>
              {user}
            </span>
            <button
              onClick={async () => {
                const h = getHeaders();
                console.log("[verify] Sending headers:", h);
                const r = await fetch(`${API}/auth/verify`, { headers: h });
                const d = await r.json();
                console.log("[verify] Result:", d);
                alert(JSON.stringify(d, null, 2));
              }}
              style={{
                background:"none", border:"none", color:G.muted,
                cursor:"pointer", fontSize:10,
                fontFamily:"'Share Tech Mono'", letterSpacing:1,
                padding:"2px 6px", borderRadius:4,
              }}
              title="Verify token (debug)">
              ●
            </button>
            <button onClick={handleLogout}
              style={{
                background:"none", border:"none", color:G.muted,
                cursor:"pointer", fontSize:11,
                fontFamily:"'Share Tech Mono'", letterSpacing:1,
                padding:"2px 6px", borderRadius:4, transition:"color 0.2s",
              }}
              onMouseOver={e => e.target.style.color = G.red}
              onMouseOut={e  => e.target.style.color = G.muted}>
              LOGOUT
            </button>
          </div>
        </div>
      </div>

      <div style={{
        display:"grid", gridTemplateColumns:"240px 1fr",
        height:"calc(100vh - 56px)",
      }}>
        {/* Sidebar */}
        <div style={{
          background:G.surface, borderRight:`1px solid ${G.border}`,
          padding:16, display:"flex", flexDirection:"column", gap:16, overflowY:"auto",
        }}>
          {/* Agents */}
          <div>
            <div style={{
              fontFamily:"'Barlow Condensed'", fontWeight:700,
              letterSpacing:2, fontSize:11, color:G.muted, marginBottom:8,
            }}>AGENTS</div>
            <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
              {Object.keys(AGENT_INFO).map(name => (
                <AgentPill key={name} name={name}
                  active={activeAgent?.includes(name.replace("Agent", ""))} />
              ))}
            </div>
          </div>

          <hr style={{ border:"none", borderTop:`1px solid ${G.border}` }} />

          {/* Controls */}
          <div>
            <div style={{
              fontFamily:"'Barlow Condensed'", fontWeight:700,
              letterSpacing:2, fontSize:11, color:G.muted, marginBottom:8,
            }}>SCENARIO</div>
            <select value={selectedScenario}
              onChange={e => setSelectedScenario(Number(e.target.value))}
              style={{
                width:"100%", background:G.card, border:`1px solid ${G.border}`,
                color:G.text, padding:"7px 10px", borderRadius:5,
                fontSize:12, marginBottom:8,
              }}>
              {scenarios.map(s => (
                <option key={s.id} value={s.id}>
                  [{s.id.toString().padStart(2, "0")}] {s.name}
                </option>
              ))}
            </select>
            <div style={{ fontSize:11, color:G.muted, marginBottom:4 }}>Random Seed</div>
            <input type="number" value={seed}
              onChange={e => setSeed(e.target.value)}
              style={{
                width:"100%", background:G.card, border:`1px solid ${G.border}`,
                color:G.text, padding:"7px 10px", borderRadius:5,
                fontSize:12, fontFamily:"'Share Tech Mono'", marginBottom:12,
              }} />
            <div style={{ display:"flex", gap:6 }}>
              <button onClick={handleRun} disabled={running}
                style={{
                  flex:1, background: running ? G.accentLo : G.accent,
                  color:"#fff", border:"none", padding:"9px 0", borderRadius:5,
                  fontFamily:"'Barlow Condensed'", fontWeight:700,
                  letterSpacing:1, fontSize:13,
                  cursor: running ? "not-allowed" : "pointer",
                  display:"flex", alignItems:"center", justifyContent:"center", gap:6,
                }}>
                {running
                  ? <><div style={{
                      width:12, height:12, border:"2px solid #fff",
                      borderTopColor:"transparent", borderRadius:"50%",
                      animation:"spin 0.7s linear infinite",
                    }} />RUN...</>
                  : "▶ START"
                }
              </button>
              <button onClick={handleReset} style={{
                background:G.card, color:G.text, border:`1px solid ${G.border}`,
                padding:"9px 12px", borderRadius:5,
                fontFamily:"'Barlow Condensed'", fontWeight:700,
                fontSize:13, cursor:"pointer",
              }}>↺</button>
            </div>
          </div>

          <hr style={{ border:"none", borderTop:`1px solid ${G.border}` }} />

          {resources.length > 0 && (
            <div>
              <div style={{
                fontFamily:"'Barlow Condensed'", fontWeight:700,
                letterSpacing:2, fontSize:11, color:G.muted, marginBottom:8,
              }}>RESOURCES</div>
              <ResourceTable resources={resources} />
            </div>
          )}

          <div>
            <div style={{
              fontFamily:"'Barlow Condensed'", fontWeight:700,
              letterSpacing:2, fontSize:11, color:G.muted, marginBottom:6,
            }}>STATE HISTORY</div>
            <div style={{ display:"flex", flexWrap:"wrap", gap:4 }}>
              {visTransitions.map((t, i) => (
                <div key={i} style={{
                  fontSize:9, padding:"2px 6px", borderRadius:10,
                  background:`${STATE_COLORS[t.to_state]}22`,
                  color:STATE_COLORS[t.to_state],
                  border:`1px solid ${STATE_COLORS[t.to_state]}44`,
                  fontFamily:"'Share Tech Mono'",
                }}>{t.to_state}</div>
              ))}
            </div>
          </div>
        </div>

        {/* Main panel */}
        <div style={{ display:"flex", flexDirection:"column", overflow:"hidden" }}>
          {/* Tab bar */}
          <div style={{
            background:G.surface, borderBottom:`1px solid ${G.border}`,
            display:"flex", padding:"0 20px",
          }}>
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{
                padding:"14px 20px", background:"none", border:"none", cursor:"pointer",
                fontFamily:"'Barlow Condensed'", fontWeight:700, letterSpacing:1, fontSize:13,
                color: tab === t.id ? G.accent : G.muted,
                borderBottom: tab === t.id ? `2px solid ${G.accent}` : "2px solid transparent",
                transition:"all 0.2s",
              }}>{t.label}</button>
            ))}
          </div>

          {error && (
            <div style={{
              background:"#7f1d1d", border:"1px solid #ef4444",
              margin:16, padding:"10px 16px", borderRadius:6,
              color:"#fca5a5", fontSize:12,
            }}>⚠️ {error} — Make sure the backend is running on localhost:8000</div>
          )}

          <div style={{ flex:1, overflowY:"auto", padding:20 }}>

            {/* ── Dashboard tab ── */}
            {tab === "dashboard" && (
              <div style={{ display:"flex", flexDirection:"column", gap:20 }}>
                <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12 }}>
                  <MetricCard label="Lives Saved" icon="🧑‍🚒"
                    value={metrics.total_lives_saved ?? "—"}
                    sub={`of ${metrics.total_lives_at_risk ?? "—"} at risk`}
                    color={G.green} />
                  <MetricCard label="Save Rate" icon="📈"
                    value={metrics.avg_save_rate ? `${metrics.avg_save_rate}%` : "—"}
                    sub="avg across events" color={G.blue} />
                  <MetricCard label="vs Baseline" icon="⚡"
                    value={metrics.lives_saved_improvement !== undefined
                      ? `+${metrics.lives_saved_improvement}` : "—"}
                    sub={metrics.improvement_pct !== undefined
                      ? `${metrics.improvement_pct}% better` : ""}
                    color={G.accent} />
                  <MetricCard label="Success Rate" icon="✅"
                    value={metrics.success_rate ? `${metrics.success_rate}%` : "—"}
                    sub={`${metrics.total_events ?? 0} events handled`}
                    color={G.purple} />
                </div>

                {eventsDetail.length > 0 && (
                  <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
                    <div style={{ background:G.card, border:`1px solid ${G.border}`, borderRadius:8, padding:16 }}>
                      <BarChart title="LIVES SAVED vs AT RISK"
                        data={eventsDetail.map(e => ({
                          label: e.location || e.event_type,
                          saved: e.lives_saved, risk: e.lives_at_risk,
                        }))}
                        labelKey="label" valueKey="saved" maxKey="risk" color={G.green} />
                    </div>
                    <div style={{ background:G.card, border:`1px solid ${G.border}`, borderRadius:8, padding:16 }}>
                      <BarChart title="MULTI-AGENT vs BASELINE"
                        data={eventsDetail.map(e => ({
                          label: e.location || e.event_type,
                          saved: e.lives_saved, baseline: e.baseline_saved,
                        }))}
                        labelKey="label" valueKey="saved" maxKey="baseline" color={G.blue} />
                    </div>
                  </div>
                )}

                {eventsDetail.length > 0 && (
                  <div style={{ background:G.card, border:`1px solid ${G.border}`, borderRadius:8, padding:16 }}>
                    <div style={{
                      fontFamily:"'Barlow Condensed'", fontWeight:700,
                      letterSpacing:1, fontSize:13, color:G.muted, marginBottom:12,
                    }}>EVENT OUTCOMES</div>
                    <div style={{ overflowX:"auto" }}>
                      <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12 }}>
                        <thead>
                          <tr style={{ borderBottom:`1px solid ${G.border}` }}>
                            {["Type","Location","Severity","At Risk","Saved","Baseline","Δ","Resources","Status"].map(h => (
                              <th key={h} style={{
                                padding:"6px 10px", textAlign:"left",
                                color:G.muted, fontFamily:"'Barlow Condensed'",
                                fontWeight:700, letterSpacing:1, fontSize:11,
                              }}>{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {eventsDetail.map((e, i) => {
                            const delta = e.lives_saved - e.baseline_saved;
                            return (
                              <tr key={i} style={{ borderBottom:`1px solid ${G.border}22` }}>
                                <td style={{ padding:"8px 10px" }}>
                                  {DISASTER_ICONS[e.event_type] || "⚠️"} {e.event_type}
                                </td>
                                <td style={{ padding:"8px 10px", color:G.blue }}>📍 {e.location}</td>
                                <td style={{ padding:"8px 10px" }}>
                                  <span style={{
                                    color:severityColor(e.severity),
                                    fontFamily:"'Share Tech Mono'", fontSize:11,
                                  }}>{e.severity}</span>
                                </td>
                                <td style={{ padding:"8px 10px", fontFamily:"'Share Tech Mono'" }}>{e.lives_at_risk}</td>
                                <td style={{ padding:"8px 10px", fontFamily:"'Share Tech Mono'", color:G.green }}>{e.lives_saved}</td>
                                <td style={{ padding:"8px 10px", fontFamily:"'Share Tech Mono'", color:G.muted }}>{e.baseline_saved}</td>
                                <td style={{ padding:"8px 10px", fontFamily:"'Share Tech Mono'",
                                  color: delta >= 0 ? G.green : G.red }}>
                                  {delta >= 0 ? "+" : ""}{delta}
                                </td>
                                <td style={{ padding:"8px 10px", fontFamily:"'Share Tech Mono'" }}>{e.resources_used}</td>
                                <td style={{ padding:"8px 10px" }}>
                                  <span style={{
                                    padding:"2px 8px", borderRadius:10, fontSize:10,
                                    background: e.success ? `${G.green}22` : `${G.red}22`,
                                    color: e.success ? G.green : G.red,
                                  }}>{e.success ? "✓ SUCCESS" : "✗ PARTIAL"}</span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {!result && !running && (
                  <div style={{ textAlign:"center", padding:60, color:G.muted }}>
                    <div style={{ fontSize:48, marginBottom:12 }}>🚨</div>
                    <div style={{
                      fontFamily:"'Barlow Condensed'", fontSize:20, letterSpacing:2,
                    }}>SELECT A SCENARIO AND PRESS START</div>
                    <div style={{ fontSize:12, marginTop:6 }}>
                      10 test scenarios · fixed-seed reproducibility
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ── Map tab ── */}
            {tab === "map" && (
              <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
                <div style={{
                  fontFamily:"'Barlow Condensed'", fontWeight:700,
                  letterSpacing:2, color:G.muted,
                }}>DISASTER MAP — {result?.scenario?.name || "No active scenario"}</div>
                <MapGrid events={mapEvents} resources={resources} />
                <div style={{ background:G.card, border:`1px solid ${G.border}`, borderRadius:8, padding:16 }}>
                  <TransitionTimeline transitions={visTransitions} />
                </div>
              </div>
            )}

            {/* ── Messages tab ── */}
            {tab === "messages" && (
              <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div style={{
                    fontFamily:"'Barlow Condensed'", fontWeight:700,
                    letterSpacing:2, color:G.muted,
                  }}>AGENT MESSAGE FEED</div>
                  <div style={{ fontFamily:"'Share Tech Mono'", fontSize:11, color:G.muted }}>
                    {visMessages.length} messages
                  </div>
                </div>
                <MessageFeed messages={visMessages} />
                <div style={{ background:G.card, border:`1px solid ${G.border}`, borderRadius:8, padding:16 }}>
                  <div style={{
                    fontFamily:"'Barlow Condensed'", fontWeight:700,
                    letterSpacing:2, fontSize:11, color:G.muted, marginBottom:8,
                  }}>STATE MACHINE TRANSITIONS</div>
                  <TransitionTimeline transitions={visTransitions} />
                </div>
              </div>
            )}

            {/* ── Agents tab ── */}
            {tab === "agents" && (
              <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
                <div style={{
                  fontFamily:"'Barlow Condensed'", fontWeight:700,
                  letterSpacing:2, color:G.muted,
                }}>AGENT INVOCATION LOG</div>
                <div style={{ background:G.card, border:`1px solid ${G.border}`, borderRadius:8, padding:16 }}>
                  <AgentLogPanel logs={visAgentLog} />
                </div>
                <div style={{ background:G.card, border:`1px solid ${G.border}`, borderRadius:8, padding:16 }}>
                  <div style={{
                    fontFamily:"'Barlow Condensed'", fontWeight:700,
                    letterSpacing:2, fontSize:11, color:G.muted, marginBottom:12,
                  }}>AGENT INTERACTION PROTOCOL</div>
                  <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap" }}>
                    {[
                      { name:"MonitorAgent",     label:"📡 MONITOR",   msg:"DISASTER_DETECTED"   },
                      { name:"ResourceAllocator",label:"⚙️ ALLOCATOR", msg:"RESOURCES_ALLOCATED"  },
                      { name:"RescueCoordinator",label:"🚁 RESCUE",    msg:"RESCUE_COMPLETE"      },
                      { name:"EvaluatorAgent",   label:"📊 EVALUATOR", msg:"EVALUATION_RESULT"   },
                    ].map((a, i, arr) => (
                      <div key={a.name} style={{ display:"flex", alignItems:"center", gap:8 }}>
                        <div style={{
                          background: activeAgent?.includes(a.name.replace("Agent",""))
                            ? `${AGENT_INFO[a.name]?.color}33` : G.grid,
                          border:`1px solid ${AGENT_INFO[a.name]?.color || G.border}`,
                          borderRadius:6, padding:"8px 14px",
                          fontFamily:"'Barlow Condensed'", fontWeight:700, fontSize:13,
                          color: AGENT_INFO[a.name]?.color,
                          boxShadow: activeAgent?.includes(a.name.replace("Agent",""))
                            ? `0 0 12px ${AGENT_INFO[a.name]?.color}55` : "none",
                          transition:"all 0.3s",
                        }}>{a.label}</div>
                        {i < arr.length - 1 && (
                          <div style={{
                            display:"flex", flexDirection:"column", alignItems:"center", gap:2,
                          }}>
                            <div style={{
                              fontSize:8, color:G.muted,
                              fontFamily:"'Share Tech Mono'", whiteSpace:"nowrap",
                            }}>{a.msg}</div>
                            <div style={{ color:G.muted, fontSize:18 }}>→</div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ── Charts tab ── */}
            {tab === "charts" && (
              <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div style={{
                    fontFamily:"'Barlow Condensed'", fontWeight:700,
                    letterSpacing:2, color:G.muted,
                  }}>PERFORMANCE OVER TIME</div>
                  {runHistory.length > 0 && (
                    <button
                      onClick={() => setRunHistory([])}
                      style={{
                        background:"none", border:`1px solid ${G.border}`,
                        color:G.muted, cursor:"pointer", fontSize:11,
                        fontFamily:"'Share Tech Mono'", letterSpacing:1,
                        padding:"4px 10px", borderRadius:4,
                      }}
                      onMouseOver={e => e.currentTarget.style.borderColor = G.red}
                      onMouseOut={e  => e.currentTarget.style.borderColor = G.border}
                    >CLEAR HISTORY</button>
                  )}
                </div>
                <div style={{ background:G.card, border:`1px solid ${G.border}`, borderRadius:8, padding:20 }}>
                  <RunHistoryChart history={runHistory} />
                </div>
              </div>
            )}

            {/* ── Comm Graph tab ── */}
            {tab === "commgraph" && (
              <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div style={{
                    fontFamily:"'Barlow Condensed'", fontWeight:700,
                    letterSpacing:2, color:G.muted,
                  }}>AGENT COMMUNICATION GRAPH</div>
                  <div style={{ fontFamily:"'Share Tech Mono'", fontSize:11, color:G.muted }}>
                    {visMessages.length} messages · current run
                  </div>
                </div>
                <div style={{ background:G.card, border:`1px solid ${G.border}`, borderRadius:8, padding:20 }}>
                  <AgentCommGraph messages={visMessages} />
                </div>
              </div>
            )}

            {/* ── Live Map tab ── */}
            {tab === "livemap" && (
              <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
                <div style={{
                  fontFamily:"'Barlow Condensed'", fontWeight:700,
                  letterSpacing:2, color:G.muted,
                }}>🗺 LIVE OPERATIONAL MAP</div>
                <LiveMap token={token} />
              </div>
            )}

            {/* ── SOS tab ── */}
            {tab === "sos" && (
              <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
                <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                  <div style={{
                    fontFamily:"'Barlow Condensed'", fontWeight:700,
                    letterSpacing:2, color:G.red, fontSize:16,
                  }}>🆘 EMERGENCY SOS SYSTEM</div>
                  <div style={{
                    fontSize:10, fontFamily:"'Share Tech Mono'",
                    color:G.muted, padding:"2px 8px",
                    background:`${G.red}11`, border:`1px solid ${G.red}33`,
                    borderRadius:10,
                  }}>LIVE</div>
                </div>
                <SOSPanel token={token} user={user} />
              </div>
            )}

            {/* ── Builder tab ── */}
            {tab === "builder" && (
              <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
                <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                  <div style={{
                    fontFamily:"'Barlow Condensed'", fontWeight:700,
                    letterSpacing:2, color:G.accent, fontSize:16,
                  }}>⚙ SCENARIO BUILDER</div>
                  <div style={{ fontSize:11, color:G.muted, fontFamily:"'Share Tech Mono'" }}>
                    FORM · AI INPUT · LIVE INJECT
                  </div>
                </div>
                <ScenarioBuilder token={token} onRunComplete={handleBuilderRun} />
              </div>
            )}

          </div>
        </div>
      </div>
    </>
  );
}

// ══════════════════════════════════════════════════════════════════════════
// ROOT APP — auth router
// ══════════════════════════════════════════════════════════════════════════

export default function App() {
  const [token, setToken] = useState(() => localStorage.getItem("dc_token") || "");
  const [user,  setUser]  = useState(() => localStorage.getItem("dc_user")  || "");
  // Derive page synchronously from stored token — no useEffect needed
  const [page, setPage]   = useState(() =>
    localStorage.getItem("dc_token") ? "app" : "login"
  );

  const handleLogin = (tok, username) => {
    localStorage.setItem("dc_token", tok);
    localStorage.setItem("dc_user",  username);
    setToken(tok); setUser(username);
    setPage("app");
  };

  const handleLogout = () => {
    localStorage.removeItem("dc_token");
    localStorage.removeItem("dc_user");
    setToken(""); setUser("");
    setPage("login");
  };

  return (
    <>
      <style>{css}</style>
      {page === "login"    && (
        <LoginPage onLogin={handleLogin} onGoRegister={() => setPage("register")} />
      )}
      {page === "register" && (
        <RegisterPage onRegistered={() => setPage("login")} onGoLogin={() => setPage("login")} />
      )}
      {page === "app"      && (
        <Dashboard token={token} user={user} onLogout={handleLogout} />
      )}
    </>
  );
}
