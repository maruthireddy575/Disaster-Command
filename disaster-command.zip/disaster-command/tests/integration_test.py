"""
Integration smoke test — runs all 10 scenarios, verifies metrics, prints report.
Run from the project root:  python tests/integration_test.py
"""

import sys
import json
import time

sys.path.insert(0, "backend")

from orchestrator import SimulationOrchestrator, SCENARIOS


def run_all():
    orch    = SimulationOrchestrator()
    results = []
    passed  = 0
    failed  = 0

    print("=" * 65)
    print("  MULTI-AGENT DISASTER SIMULATOR — INTEGRATION TEST SUITE")
    print("=" * 65)

    for sc in SCENARIOS:
        t0      = time.time()
        res     = orch.run(scenario_id=sc["id"], seed=42)
        elapsed = time.time() - t0
        m       = res.get("metrics", {})

        ok = (
            m.get("total_events",    0) >= 1 and
            m.get("avg_save_rate",   0) > 0  and
            m.get("total_lives_saved", 0) >= 0 and
            len(res.get("transitions", [])) >= 3 and
            len(res.get("messages",    [])) >= 2
        )

        status = "✅ PASS" if ok else "❌ FAIL"
        if ok: passed += 1
        else:  failed += 1
        results.append({**res, "test_ok": ok})

        print(f"\n[{sc['id']:02d}] {sc['name']}")
        print(f"     Status:        {status}  ({elapsed:.2f}s)")
        print(f"     Events:        {m.get('total_events', 0)}")
        print(f"     Lives at risk: {m.get('total_lives_at_risk', 0)}")
        print(f"     Lives saved:   {m.get('total_lives_saved', 0)}")
        print(f"     Avg save rate: {m.get('avg_save_rate', 0):.1f}%")
        print(f"     vs Baseline:   +{m.get('lives_saved_improvement', 0)} ({m.get('improvement_pct', 0):.1f}%)")
        print(f"     State machine: {len(res.get('transitions', []))} transitions")
        print(f"     Messages:      {len(res.get('messages', []))}")

    print("\n" + "=" * 65)
    print(f"  RESULTS: {passed}/{len(SCENARIOS)} PASSED, {failed} FAILED")
    print("=" * 65)

    total_at_risk = sum(r["metrics"].get("total_lives_at_risk", 0) for r in results)
    total_saved   = sum(r["metrics"].get("total_lives_saved",   0) for r in results)
    avg_improve   = sum(r["metrics"].get("improvement_pct",     0) for r in results) / len(results)

    print(f"  Aggregate lives at risk : {total_at_risk}")
    print(f"  Aggregate lives saved   : {total_saved}")
    print(f"  Avg improvement vs base : {avg_improve:.1f}%")
    print("=" * 65)

    report_path = "data/evaluation_report.json"
    with open(report_path, "w") as f:
        json.dump({
            "scenarios_tested":          len(SCENARIOS),
            "passed":                    passed,
            "failed":                    failed,
            "aggregate_lives_at_risk":   total_at_risk,
            "aggregate_lives_saved":     total_saved,
            "avg_improvement_pct":       round(avg_improve, 2),
            "results":                   results,
        }, f, indent=2)
    print(f"  Evaluation report saved → {report_path}")


if __name__ == "__main__":
    run_all()
