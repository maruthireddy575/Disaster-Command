# test_hash.py
from auth_db import hash_password, verify_password

# Test with a long password (more than 72 bytes)
long_password = "x" * 100
print(f"Password length: {len(long_password)} characters")
print(f"Password bytes: {len(long_password.encode('utf-8'))} bytes")

# Hash it
hashed = hash_password(long_password)
print(f"Hashed successfully: {hashed[:50]}...")

# Verify it
is_valid = verify_password(long_password, hashed)
print(f"Verification: {is_valid}")

# Test with short password
short_password = "test123"
hashed2 = hash_password(short_password)
print(f"\nShort password hash: {hashed2[:50]}...")
print(f"Verification: {verify_password(short_password, hashed2)}")