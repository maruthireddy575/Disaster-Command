"""
Multi-Agent Disaster Management Simulator
Core Agent Definitions and State Machine
"""

import uuid
import time
import random
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Any


# ─────────────────────────────────────────────
# ENUMS
# ─────────────────────────────────────────────

class SystemState(str, Enum):
    IDLE        = "IDLE"
    MONITORING  = "MONITORING"
    ALERT       = "ALERT"
    DISPATCHING = "DISPATCHING"
    RESCUING    = "RESCUING"
    REPLANNING  = "REPLANNING"
    RESOLVED    = "RESOLVED"


class AgentRole(str, Enum):
    MONITOR   = "MonitorAgent"
    ALLOCATOR = "ResourceAllocator"
    RESCUE    = "RescueCoordinator"
    EVALUATOR = "EvaluatorAgent"


class EventSeverity(str, Enum):
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"


# ─────────────────────────────────────────────
# DATA MODELS
# ─────────────────────────────────────────────

@dataclass
class DisasterEvent:
    id: str
    type: str
    severity: str
    location: str
    grid_x: int
    grid_y: int
    affected_people: int
    timestamp: float = field(default_factory=time.time)
    resolved: bool = False


@dataclass
class Resource:
    id: str
    type: str
    location: str
    grid_x: int
    grid_y: int
    available: bool = True
    assigned_to: Optional[str] = None


@dataclass
class AgentMessage:
    id: str
    sender: str
    receiver: str
    msg_type: str
    payload: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)


@dataclass
class StateTransition:
    from_state: str
    to_state: str
    trigger: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class RescueOperation:
    event_id: str
    resources_assigned: List[str]
    lives_at_risk: int
    lives_saved: int = 0
    start_time: float = field(default_factory=time.time)
    end_time: Optional[float] = None
    success: bool = False


# ─────────────────────────────────────────────
# SIMULATION WORLD
# ─────────────────────────────────────────────

DISASTER_TYPES = ["flood", "fire", "earthquake", "chemical_spill", "building_collapse"]

LOCATIONS = [
    ("Downtown",    2, 2), ("Airport",    7, 1), ("Harbor",      1, 6),
    ("Hospital",    4, 4), ("University", 6, 6), ("Industrial",  8, 3),
    ("Residential", 3, 7), ("Suburb",     9, 8), ("Market",      5, 2),
    ("Stadium",     2, 9),
]

RESOURCE_TYPES = ["ambulance", "fire_truck", "rescue_team", "helicopter"]

SEVERITY_WEIGHTS = {
    EventSeverity.LOW:      {"save_rate": 0.95, "resource_multiplier": 1},
    EventSeverity.MEDIUM:   {"save_rate": 0.80, "resource_multiplier": 2},
    EventSeverity.HIGH:     {"save_rate": 0.65, "resource_multiplier": 3},
    EventSeverity.CRITICAL: {"save_rate": 0.45, "resource_multiplier": 4},
}


def manhattan(ax, ay, bx, by):
    return abs(ax - bx) + abs(ay - by)


# ─────────────────────────────────────────────
# AGENT 1 — MONITOR AGENT
# ─────────────────────────────────────────────

class MonitorAgent:
    """Watches the environment and detects disasters. Emits ALERT messages."""

    def __init__(self, rng: random.Random):
        self.role = AgentRole.MONITOR
        self.rng  = rng
        self.active_events: List[DisasterEvent] = []

    def scan(self, scenario: Dict) -> List[AgentMessage]:
        messages = []
        for ev_def in scenario.get("events", []):
            loc_name, gx, gy = next(
                (l for l in LOCATIONS if l[0] == ev_def["location"]),
                ("Unknown", 5, 5),
            )
            event = DisasterEvent(
                id=str(uuid.uuid4())[:8],
                type=ev_def["type"],
                severity=ev_def["severity"],
                location=loc_name,
                grid_x=gx,
                grid_y=gy,
                affected_people=ev_def["affected_people"],
            )
            self.active_events.append(event)
            messages.append(AgentMessage(
                id=str(uuid.uuid4())[:8],
                sender=AgentRole.MONITOR,
                receiver=AgentRole.ALLOCATOR,
                msg_type="DISASTER_DETECTED",
                payload=asdict(event),
            ))
        return messages

    def report_new_event(self) -> AgentMessage:
        """Dynamically inject a random new event (for replanning)."""
        loc      = self.rng.choice(LOCATIONS)
        severity = self.rng.choice(list(EventSeverity))
        event    = DisasterEvent(
            id=str(uuid.uuid4())[:8],
            type=self.rng.choice(DISASTER_TYPES),
            severity=severity,
            location=loc[0],
            grid_x=loc[1],
            grid_y=loc[2],
            affected_people=self.rng.randint(10, 300),
        )
        self.active_events.append(event)
        return AgentMessage(
            id=str(uuid.uuid4())[:8],
            sender=AgentRole.MONITOR,
            receiver=AgentRole.ALLOCATOR,
            msg_type="NEW_EVENT_DETECTED",
            payload=asdict(event),
        )


# ─────────────────────────────────────────────
# AGENT 2 — RESOURCE ALLOCATOR AGENT
# ─────────────────────────────────────────────

class ResourceAllocatorAgent:
    """Receives disaster alerts, assigns available resources intelligently."""

    def __init__(self, resources: List[Resource]):
        self.role      = AgentRole.ALLOCATOR
        self.resources = resources

    def allocate(self, events: List[DisasterEvent]) -> List[AgentMessage]:
        messages = []
        severity_order = [
            EventSeverity.CRITICAL, EventSeverity.HIGH,
            EventSeverity.MEDIUM,   EventSeverity.LOW,
        ]
        sorted_events = sorted(
            events,
            key=lambda e: severity_order.index(e.severity)
                if e.severity in severity_order else 99,
        )
        for event in sorted_events:
            if event.resolved:
                continue
            needed   = SEVERITY_WEIGHTS[event.severity]["resource_multiplier"]
            assigned = self._find_nearest_resources(event, needed)
            for res in assigned:
                res.available   = False
                res.assigned_to = event.id
            messages.append(AgentMessage(
                id=str(uuid.uuid4())[:8],
                sender=AgentRole.ALLOCATOR,
                receiver=AgentRole.RESCUE,
                msg_type="RESOURCES_ALLOCATED",
                payload={
                    "event":              asdict(event),
                    "assigned_resources": [asdict(r) for r in assigned],
                    "resources_found":    len(assigned),
                    "resources_needed":   needed,
                },
            ))
        return messages

    def _find_nearest_resources(self, event: DisasterEvent, count: int) -> List[Resource]:
        available = [r for r in self.resources if r.available]
        available.sort(key=lambda r: manhattan(r.grid_x, r.grid_y, event.grid_x, event.grid_y))
        return available[:count]

    def release_resources(self, event_id: str):
        for r in self.resources:
            if r.assigned_to == event_id:
                r.available   = True
                r.assigned_to = None


# ─────────────────────────────────────────────
# AGENT 3 — RESCUE COORDINATOR AGENT
# ─────────────────────────────────────────────

class RescueCoordinatorAgent:
    """Executes rescue operations, calculates outcomes, triggers replanning."""

    def __init__(self, rng: random.Random):
        self.role                = AgentRole.RESCUE
        self.rng                 = rng
        self.operations:          List[RescueOperation] = []
        self.baseline_operations: List[RescueOperation] = []

    def execute(self, allocation_msg: AgentMessage) -> AgentMessage:
        event_data   = allocation_msg.payload["event"]
        resources    = allocation_msg.payload["assigned_resources"]
        lives_at_risk = event_data["affected_people"]
        severity     = event_data["severity"]

        base_rate      = SEVERITY_WEIGHTS[severity]["save_rate"]
        resource_bonus = min(len(resources) * 0.04, 0.20)
        save_rate      = min(base_rate + resource_bonus, 0.99)
        lives_saved    = min(
            int(lives_at_risk * save_rate * (0.9 + self.rng.random() * 0.2)),
            lives_at_risk,
        )

        op = RescueOperation(
            event_id=event_data["id"],
            resources_assigned=[r["id"] for r in resources],
            lives_at_risk=lives_at_risk,
            lives_saved=lives_saved,
            end_time=time.time(),
            success=lives_saved >= lives_at_risk * 0.5,
        )
        self.operations.append(op)

        baseline_rate  = max(base_rate - 0.20, 0.10)
        baseline_saved = int(lives_at_risk * baseline_rate)
        self.baseline_operations.append(RescueOperation(
            event_id=event_data["id"] + "_baseline",
            resources_assigned=["single_resource"],
            lives_at_risk=lives_at_risk,
            lives_saved=baseline_saved,
            end_time=time.time(),
            success=baseline_saved >= lives_at_risk * 0.5,
        ))

        return AgentMessage(
            id=str(uuid.uuid4())[:8],
            sender=AgentRole.RESCUE,
            receiver=AgentRole.EVALUATOR,
            msg_type="RESCUE_COMPLETE",
            payload={
                "event_id":      event_data["id"],
                "event_type":    event_data["type"],
                "location":      event_data["location"],
                "severity":      severity,
                "lives_at_risk": lives_at_risk,
                "lives_saved":   lives_saved,
                "resources_used":len(resources),
                "save_rate":     round(save_rate, 3),
                "success":       op.success,
                "baseline_saved":baseline_saved,
            },
        )


# ─────────────────────────────────────────────
# AGENT 4 — EVALUATOR AGENT
# ─────────────────────────────────────────────

class EvaluatorAgent:
    """Aggregates metrics, compares against baseline, scores the run."""

    def __init__(self):
        self.role    = AgentRole.EVALUATOR
        self.results: List[Dict] = []

    def evaluate(self, rescue_msg: AgentMessage) -> AgentMessage:
        p = rescue_msg.payload
        self.results.append(p)
        improvement     = p["lives_saved"] - p["baseline_saved"]
        improvement_pct = (improvement / max(p["baseline_saved"], 1)) * 100
        return AgentMessage(
            id=str(uuid.uuid4())[:8],
            sender=AgentRole.EVALUATOR,
            receiver="SYSTEM",
            msg_type="EVALUATION_RESULT",
            payload={
                **p,
                "improvement_over_baseline": improvement,
                "improvement_pct":           round(improvement_pct, 1),
            },
        )

    def final_report(self) -> Dict:
        if not self.results:
            return {}
        total_at_risk  = sum(r["lives_at_risk"]  for r in self.results)
        total_saved    = sum(r["lives_saved"]     for r in self.results)
        total_baseline = sum(r["baseline_saved"]  for r in self.results)
        avg_save_rate  = sum(r["save_rate"]       for r in self.results) / len(self.results)
        success_count  = sum(1 for r in self.results if r["success"])
        return {
            "total_events":            len(self.results),
            "total_lives_at_risk":     total_at_risk,
            "total_lives_saved":       total_saved,
            "total_baseline_saved":    total_baseline,
            "lives_saved_improvement": total_saved - total_baseline,
            "improvement_pct":         round((total_saved - total_baseline) / max(total_baseline, 1) * 100, 1),
            "avg_save_rate":           round(avg_save_rate * 100, 1),
            "success_rate":            round(success_count / len(self.results) * 100, 1),
            "events_detail":           self.results,
        }
