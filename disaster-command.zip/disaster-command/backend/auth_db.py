"""
auth_db.py — SQLite database + user authentication
Uses SQLAlchemy (sync) + direct bcrypt for password hashing.
"""

import os
import uuid
import secrets
import bcrypt
from datetime import datetime, timedelta
from typing import Optional
from pathlib import Path

from sqlalchemy import (
    create_engine, Column, String, DateTime, Boolean, Text,
)
from sqlalchemy.orm import declarative_base, sessionmaker, Session

# ── Database setup ─────────────────────────────────────────────────────────
_BASE_DIR = Path(__file__).resolve().parent.parent
_DB_DIR = _BASE_DIR / "database"
_DB_DIR.mkdir(exist_ok=True)

DB_PATH = os.environ.get("DB_PATH", str(_DB_DIR / "disaster_cmd.db"))
ENGINE = create_engine(f"sqlite:///{DB_PATH}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=ENGINE, autocommit=False, autoflush=False)
Base = declarative_base()


# ── Models ─────────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    username = Column(String(64), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    display_name = Column(String(128), nullable=True)
    hashed_pw = Column(Text, nullable=False)
    role = Column(String(32), default="operator")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)


class SOSAlert(Base):
    __tablename__ = "sos_alerts"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), nullable=False, index=True)
    username = Column(String(64), nullable=False)
    display_name = Column(String(128), nullable=True)
    message = Column(Text, nullable=False)
    latitude = Column(String(32), nullable=True)
    longitude = Column(String(32), nullable=True)
    location_name = Column(String(255), nullable=True)
    severity = Column(String(16), default="HIGH")
    status = Column(String(16), default="OPEN")
    created_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)
    admin_note = Column(Text, nullable=True)


class SessionToken(Base):
    __tablename__ = "sessions"
    token = Column(String(64), primary_key=True)
    user_id = Column(String(36), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    is_valid = Column(Boolean, default=True)


# ── Database functions ─────────────────────────────────────────────────────

def create_tables():
    Base.metadata.create_all(bind=ENGINE)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ── Password helpers (Direct bcrypt) ─────────────────────────────────────

def hash_password(plain: str) -> str:
    """Hash a password using bcrypt directly (handles 72-byte limit)."""
    # Convert to bytes and truncate to 72 bytes if needed
    password_bytes = plain.encode('utf-8')
    if len(password_bytes) > 72:
        password_bytes = password_bytes[:72]
    
    # Generate salt and hash
    salt = bcrypt.gensalt(rounds=12)
    hashed = bcrypt.hashpw(password_bytes, salt)
    
    # Return as string for database storage
    return hashed.decode('utf-8')


def verify_password(plain: str, hashed: str) -> bool:
    """Verify a password against its bcrypt hash."""
    # Convert to bytes and truncate to 72 bytes if needed
    password_bytes = plain.encode('utf-8')
    if len(password_bytes) > 72:
        password_bytes = password_bytes[:72]
    
    # Verify (hashed is stored as string, convert to bytes)
    try:
        return bcrypt.checkpw(password_bytes, hashed.encode('utf-8'))
    except Exception:
        return False


# ── Session helpers ───────────────────────────────────────────────────────

def create_session_token(db: Session, user_id: str, ttl_hours: int = 24) -> str:
    token = secrets.token_hex(32)
    sess = SessionToken(
        token=token,
        user_id=user_id,
        expires_at=datetime.utcnow() + timedelta(hours=ttl_hours),
    )
    db.add(sess)
    db.commit()
    return token


def get_user_by_token(db: Session, token: str) -> Optional[User]:
    sess = db.query(SessionToken).filter_by(token=token, is_valid=True).first()
    if not sess or sess.expires_at < datetime.utcnow():
        return None
    return db.query(User).filter_by(id=sess.user_id, is_active=True).first()


def invalidate_token(db: Session, token: str):
    sess = db.query(SessionToken).filter_by(token=token).first()
    if sess:
        sess.is_valid = False
        db.commit()


# ── Auth operations ───────────────────────────────────────────────────────

def register_user(
    db: Session,
    username: str,
    email: str,
    password: str,
    display_name: str = "",
) -> tuple[bool, str]:
    if db.query(User).filter_by(username=username).first():
        return False, "Username already taken"
    if db.query(User).filter_by(email=email).first():
        return False, "Email already registered"
    if len(password) < 6:
        return False, "Password must be at least 6 characters"
    
    user = User(
        username=username,
        email=email,
        display_name=display_name or username,
        hashed_pw=hash_password(password),
    )
    db.add(user)
    db.commit()
    return True, "ok"


def login_user(
    db: Session,
    username: str,
    password: str,
) -> tuple[Optional[str], str]:
    user = db.query(User).filter_by(username=username, is_active=True).first()
    if not user or not verify_password(password, user.hashed_pw):
        return None, "Invalid username or password"
    user.last_login = datetime.utcnow()
    db.commit()
    token = create_session_token(db, user.id)
    return token, "ok"


# ── SOS operations ────────────────────────────────────────────────────────

def create_sos(
    db: Session,
    user_id: str,
    username: str,
    display_name: str,
    message: str,
    severity: str = "HIGH",
    latitude: str = None,
    longitude: str = None,
    location_name: str = None,
) -> SOSAlert:
    alert = SOSAlert(
        user_id=user_id,
        username=username,
        display_name=display_name or username,
        message=message,
        severity=severity,
        latitude=latitude,
        longitude=longitude,
        location_name=location_name,
    )
    db.add(alert)
    db.commit()
    db.refresh(alert)
    return alert


def list_sos(db: Session, status: str = None) -> list:
    q = db.query(SOSAlert).order_by(SOSAlert.created_at.desc())
    if status:
        q = q.filter_by(status=status)
    return q.all()


def update_sos_status(
    db: Session,
    alert_id: str,
    status: str,
    admin_note: str = None,
) -> Optional[SOSAlert]:
    alert = db.query(SOSAlert).filter_by(id=alert_id).first()
    if not alert:
        return None
    alert.status = status
    if admin_note:
        alert.admin_note = admin_note
    if status == "RESOLVED":
        alert.resolved_at = datetime.utcnow()
    db.commit()
    db.refresh(alert)
    return alert