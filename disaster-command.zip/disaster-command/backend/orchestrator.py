"""
Orchestrator: runs the state machine, drives agent interactions,
logs every transition and message, supports fixed-seed replay.
"""

import uuid
import time
import random
from dataclasses import asdict
from typing import List, Dict, Optional

from agents import (
    SystemState, AgentRole, EventSeverity,
    DisasterEvent, Resource, AgentMessage, StateTransition, RescueOperation,
    MonitorAgent, ResourceAllocatorAgent, RescueCoordinatorAgent, EvaluatorAgent,
    LOCATIONS, RESOURCE_TYPES,
)


# ─────────────────────────────────────────────
# SCENARIOS  (10 reproducible test cases)
# ─────────────────────────────────────────────

SCENARIOS = [
    {
        "id": 1, "name": "Single Fire – Low Severity",
        "events": [{"type":"fire","severity":"LOW","location":"Downtown","affected_people":30}],
    },
    {
        "id": 2, "name": "Dual Flood – Medium Severity",
        "events": [
            {"type":"flood","severity":"MEDIUM","location":"Harbor","affected_people":120},
            {"type":"flood","severity":"MEDIUM","location":"Suburb","affected_people":80},
        ],
    },
    {
        "id": 3, "name": "Earthquake – High Severity",
        "events": [{"type":"earthquake","severity":"HIGH","location":"Residential","affected_people":250}],
    },
    {
        "id": 4, "name": "Critical Chemical Spill",
        "events": [{"type":"chemical_spill","severity":"CRITICAL","location":"Industrial","affected_people":400}],
    },
    {
        "id": 5, "name": "Multi-Site Mass Casualty",
        "events": [
            {"type":"building_collapse","severity":"CRITICAL","location":"Stadium","affected_people":500},
            {"type":"fire","severity":"HIGH","location":"Market","affected_people":150},
            {"type":"flood","severity":"MEDIUM","location":"Airport","affected_people":200},
        ],
    },
    {
        "id": 6, "name": "Airport Emergency",
        "events": [{"type":"fire","severity":"HIGH","location":"Airport","affected_people":320}],
    },
    {
        "id": 7, "name": "Hospital Evacuation",
        "events": [{"type":"chemical_spill","severity":"HIGH","location":"Hospital","affected_people":180}],
    },
    {
        "id": 8, "name": "Campus Crisis",
        "events": [
            {"type":"fire","severity":"MEDIUM","location":"University","affected_people":90},
            {"type":"flood","severity":"LOW","location":"Suburb","affected_people":40},
        ],
    },
    {
        "id": 9, "name": "Dynamic Re-planning Test",
        "events": [
            {"type":"earthquake","severity":"HIGH","location":"Downtown","affected_people":300},
            {"type":"fire","severity":"MEDIUM","location":"Residential","affected_people":60},
        ],
        "dynamic": True,
    },
    {
        "id": 10, "name": "All-Hands Critical Response",
        "events": [
            {"type":"earthquake","severity":"CRITICAL","location":"Downtown","affected_people":600},
            {"type":"building_collapse","severity":"HIGH","location":"Market","affected_people":220},
            {"type":"flood","severity":"HIGH","location":"Harbor","affected_people":190},
            {"type":"fire","severity":"MEDIUM","location":"Industrial","affected_people":100},
        ],
    },
]


# ─────────────────────────────────────────────
# ORCHESTRATOR
# ─────────────────────────────────────────────

class SimulationOrchestrator:

    def __init__(self):
        self.run_id:   Optional[str]          = None
        self.state:    SystemState             = SystemState.IDLE
        self.seed:     Optional[int]           = None
        self.rng:      Optional[random.Random] = None

        self.monitor:   Optional[MonitorAgent]           = None
        self.allocator: Optional[ResourceAllocatorAgent] = None
        self.rescue:    Optional[RescueCoordinatorAgent] = None
        self.evaluator: Optional[EvaluatorAgent]         = None

        self.messages:          List[Dict] = []
        self.transitions:       List[Dict] = []
        self.agent_log:         List[Dict] = []
        self.final_metrics:     Dict       = {}
        self.resources:         List[Resource] = []
        self.current_scenario:  Optional[Dict] = None

    # ── helpers ───────────────────────────────

    def _log_message(self, msg: AgentMessage):
        self.messages.append({**asdict(msg), "timestamp": msg.timestamp})

    def _transition(self, new_state: SystemState, trigger: str):
        t = StateTransition(from_state=self.state, to_state=new_state, trigger=trigger)
        self.transitions.append(asdict(t))
        self.state = new_state

    def _log_agent(self, agent: str, action: str, detail: str = ""):
        self.agent_log.append({
            "agent": agent, "action": action,
            "detail": detail, "timestamp": time.time(),
        })

    # ── resource factory ──────────────────────

    def _build_resources(self) -> List[Resource]:
        resources = []
        res_id    = 0
        counts    = {"ambulance":4, "fire_truck":3, "rescue_team":4, "helicopter":2}
        for rtype in RESOURCE_TYPES:
            for i in range(counts[rtype]):
                loc = LOCATIONS[res_id % len(LOCATIONS)]
                resources.append(Resource(
                    id=f"{rtype[:3].upper()}-{i+1:02d}",
                    type=rtype,
                    location=loc[0],
                    grid_x=loc[1],
                    grid_y=loc[2],
                ))
                res_id += 1
        return resources

    # ── main run ──────────────────────────────

    def run(self, scenario_id: int, seed: int = 42) -> Dict:
        scenario = next((s for s in SCENARIOS if s["id"] == scenario_id), None)
        if not scenario:
            return {"error": f"Scenario {scenario_id} not found"}

        # Initialise
        self.run_id           = str(uuid.uuid4())[:12]
        self.seed             = seed
        self.rng              = random.Random(seed)
        self.messages         = []
        self.transitions      = []
        self.agent_log        = []
        self.final_metrics    = {}
        self.current_scenario = scenario

        self.resources  = self._build_resources()
        self.monitor    = MonitorAgent(self.rng)
        self.allocator  = ResourceAllocatorAgent(self.resources)
        self.rescue     = RescueCoordinatorAgent(self.rng)
        self.evaluator  = EvaluatorAgent()

        self._transition(SystemState.MONITORING, "run_started")

        # 1. Monitor scan
        self._log_agent(AgentRole.MONITOR, "scan", f"Scanning scenario: {scenario['name']}")
        alert_msgs = self.monitor.scan(scenario)
        for m in alert_msgs:
            self._log_message(m)
        self._log_agent(AgentRole.MONITOR, "detected", f"{len(alert_msgs)} disaster(s) found")

        if alert_msgs:
            self._transition(SystemState.ALERT, f"{len(alert_msgs)}_disasters_detected")

        # 2. Resource allocation
        self._transition(SystemState.DISPATCHING, "allocating_resources")
        self._log_agent(AgentRole.ALLOCATOR, "allocate", "Prioritising events by severity")
        alloc_msgs = self.allocator.allocate(self.monitor.active_events)
        for m in alloc_msgs:
            self._log_message(m)
        self._log_agent(AgentRole.ALLOCATOR, "dispatched", f"{len(alloc_msgs)} allocation(s) sent")

        # 3. Rescue operations
        self._transition(SystemState.RESCUING, "resources_dispatched")
        for am in alloc_msgs:
            self._log_agent(
                AgentRole.RESCUE, "execute",
                f"Rescue op for event {am.payload['event']['id']} @ {am.payload['event']['location']}",
            )
            rescue_msg = self.rescue.execute(am)
            self._log_message(rescue_msg)

            eval_msg = self.evaluator.evaluate(rescue_msg)
            self._log_message(eval_msg)
            self._log_agent(
                AgentRole.EVALUATOR, "scored",
                f"Event {rescue_msg.payload['event_id']}: "
                f"{rescue_msg.payload['lives_saved']}/{rescue_msg.payload['lives_at_risk']} saved",
            )
            self.allocator.release_resources(am.payload["event"]["id"])

        # 4. Dynamic replanning (scenario 9)
        if scenario.get("dynamic"):
            self._transition(SystemState.REPLANNING, "new_event_detected")
            self._log_agent(AgentRole.MONITOR, "dynamic_scan", "New event injected mid-simulation")
            new_event_msg = self.monitor.report_new_event()
            self._log_message(new_event_msg)

            new_alloc = self.allocator.allocate([self.monitor.active_events[-1]])
            for m in new_alloc:
                self._log_message(m)
                rescue_msg = self.rescue.execute(m)
                self._log_message(rescue_msg)
                eval_msg   = self.evaluator.evaluate(rescue_msg)
                self._log_message(eval_msg)
                self.allocator.release_resources(m.payload["event"]["id"])

        # 5. Final evaluation
        self._transition(SystemState.RESOLVED, "all_events_handled")
        self.final_metrics = self.evaluator.final_report()
        self._log_agent(
            AgentRole.EVALUATOR, "final_report",
            f"Saved {self.final_metrics.get('total_lives_saved',0)} / "
            f"{self.final_metrics.get('total_lives_at_risk',0)} lives",
        )

        return self._package_result()

    def _package_result(self) -> Dict:
        return {
            "run_id":       self.run_id,
            "seed":         self.seed,
            "scenario":     self.current_scenario,
            "final_state":  self.state,
            "messages":     self.messages,
            "transitions":  self.transitions,
            "agent_log":    self.agent_log,
            "metrics":      self.final_metrics,
            "resources":    [asdict(r) for r in self.resources],
        }

    def run_custom(self, scenario: Dict, seed: int = 42) -> Dict:
        """Run a user-built custom scenario (same pipeline as run())."""
        # Assign a temporary ID so the UI can reference it
        scenario = {**scenario, "id": 0}
        self.run_id           = str(uuid.uuid4())[:12]
        self.seed             = seed
        self.rng              = random.Random(seed)
        self.messages         = []
        self.transitions      = []
        self.agent_log        = []
        self.final_metrics    = {}
        self.current_scenario = scenario

        self.resources  = self._build_resources()
        self.monitor    = MonitorAgent(self.rng)
        self.allocator  = ResourceAllocatorAgent(self.resources)
        self.rescue     = RescueCoordinatorAgent(self.rng)
        self.evaluator  = EvaluatorAgent()

        self._transition(SystemState.MONITORING, "custom_run_started")

        self._log_agent(AgentRole.MONITOR, "scan", f"Custom scenario: {scenario.get('name','User Scenario')}")
        alert_msgs = self.monitor.scan(scenario)
        for m in alert_msgs:
            self._log_message(m)
        self._log_agent(AgentRole.MONITOR, "detected", f"{len(alert_msgs)} disaster(s) found")

        if alert_msgs:
            self._transition(SystemState.ALERT, f"{len(alert_msgs)}_disasters_detected")

        self._transition(SystemState.DISPATCHING, "allocating_resources")
        self._log_agent(AgentRole.ALLOCATOR, "allocate", "Prioritising events by severity")
        alloc_msgs = self.allocator.allocate(self.monitor.active_events)
        for m in alloc_msgs:
            self._log_message(m)
        self._log_agent(AgentRole.ALLOCATOR, "dispatched", f"{len(alloc_msgs)} allocation(s) sent")

        self._transition(SystemState.RESCUING, "resources_dispatched")
        for am in alloc_msgs:
            self._log_agent(
                AgentRole.RESCUE, "execute",
                f"Rescue op for event {am.payload['event']['id']} @ {am.payload['event']['location']}",
            )
            rescue_msg = self.rescue.execute(am)
            self._log_message(rescue_msg)
            eval_msg = self.evaluator.evaluate(rescue_msg)
            self._log_message(eval_msg)
            self._log_agent(
                AgentRole.EVALUATOR, "scored",
                f"Event {rescue_msg.payload['event_id']}: "
                f"{rescue_msg.payload['lives_saved']}/{rescue_msg.payload['lives_at_risk']} saved",
            )
            self.allocator.release_resources(am.payload["event"]["id"])

        self._transition(SystemState.RESOLVED, "all_events_handled")
        self.final_metrics = self.evaluator.final_report()
        self._log_agent(
            AgentRole.EVALUATOR, "final_report",
            f"Saved {self.final_metrics.get('total_lives_saved',0)} / "
            f"{self.final_metrics.get('total_lives_at_risk',0)} lives",
        )
        return self._package_result()

    def inject_event(self, event_def: Dict, seed: int = None) -> Dict:
        """Inject a new event into an already-running or idle simulation."""
        if not self.monitor:
            # No active run — bootstrap minimal state
            self.run_id        = str(uuid.uuid4())[:12]
            self.seed          = seed or 42
            self.rng           = random.Random(self.seed)
            self.resources     = self._build_resources()
            self.monitor       = MonitorAgent(self.rng)
            self.allocator     = ResourceAllocatorAgent(self.resources)
            self.rescue        = RescueCoordinatorAgent(self.rng)
            self.evaluator     = EvaluatorAgent()
            self.messages      = []
            self.transitions   = []
            self.agent_log     = []
            self.final_metrics = {}
            self.current_scenario = {"id":0, "name":"Live Injection", "events":[]}
            self._transition(SystemState.MONITORING, "live_injection_started")

        # Inject via monitor
        mini_scenario = {"events": [event_def]}
        self._transition(SystemState.REPLANNING, "event_injected")
        self._log_agent(AgentRole.MONITOR, "inject",
                        f"Live inject: {event_def.get('type')} @ {event_def.get('location')}")
        alert_msgs = self.monitor.scan(mini_scenario)
        for m in alert_msgs:
            self._log_message(m)

        new_events = [self.monitor.active_events[-1]] if self.monitor.active_events else []
        alloc_msgs = self.allocator.allocate(new_events)
        for m in alloc_msgs:
            self._log_message(m)

        self._transition(SystemState.RESCUING, "injected_resources_dispatched")
        for am in alloc_msgs:
            rescue_msg = self.rescue.execute(am)
            self._log_message(rescue_msg)
            eval_msg   = self.evaluator.evaluate(rescue_msg)
            self._log_message(eval_msg)
            self.allocator.release_resources(am.payload["event"]["id"])

        self._transition(SystemState.RESOLVED, "injection_handled")
        self.final_metrics = self.evaluator.final_report()
        return self._package_result()

    def get_scenarios(self) -> List[Dict]:
        return [
            {"id": s["id"], "name": s["name"], "event_count": len(s["events"])}
            for s in SCENARIOS
        ]
