"""
FastAPI backend — Disaster Command v3
Auth + simulation routes + SOS emergency system + live map data.
"""

from fastapi import FastAPI, HTTPException, Header, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
from sqlalchemy.orm import Session
from datetime import datetime

from orchestrator import SimulationOrchestrator, SCENARIOS
from auth_db import (
    create_tables, get_db,
    register_user, login_user,
    get_user_by_token, invalidate_token,
    create_sos, list_sos, update_sos_status,
)

# ── Bootstrap DB ───────────────────────────────────────────────────────────
create_tables()

app = FastAPI(title="Disaster Command API", version="3.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*", "Authorization", "Content-Type", "Accept"],
    expose_headers=["*"],
)

orchestrator = SimulationOrchestrator()


# ── Schemas ────────────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    username:     str
    email:        str
    password:     str
    display_name: Optional[str] = ""

class LoginRequest(BaseModel):
    username: str
    password: str

class RunRequest(BaseModel):
    scenario_id: int
    seed:        Optional[int] = 42

class CustomScenarioEvent(BaseModel):
    type:             str
    severity:         str
    location:         str
    affected_people:  int

class CustomRunRequest(BaseModel):
    name:   str
    events: List[CustomScenarioEvent]
    seed:   Optional[int] = 42

class InjectEventRequest(BaseModel):
    type:            str
    severity:        str
    location:        str
    affected_people: int
    seed:            Optional[int] = None

class NLPParseRequest(BaseModel):
    text: str

class SOSRequest(BaseModel):
    message:       str
    severity:      Optional[str] = "HIGH"
    latitude:      Optional[str] = None
    longitude:     Optional[str] = None
    location_name: Optional[str] = None

class SOSUpdateRequest(BaseModel):
    status:     str          # OPEN | ACKNOWLEDGED | RESOLVED
    admin_note: Optional[str] = None


# ── Auth dependency ────────────────────────────────────────────────────────

def _extract_token(request: Request) -> str:
    auth = (
        request.headers.get("authorization") or
        request.headers.get("Authorization") or
        ""
    )
    if not auth.lower().startswith("bearer "):
        raise HTTPException(status_code=401,
            detail="Missing or invalid Authorization header",
            headers={"WWW-Authenticate": "Bearer"})
    return auth.split(" ", 1)[1].strip()

def require_auth(request: Request, db: Session = Depends(get_db)):
    token = _extract_token(request)
    user  = get_user_by_token(db, token)
    if not user:
        raise HTTPException(status_code=401,
            detail="Invalid or expired session",
            headers={"WWW-Authenticate": "Bearer"})
    return user

def require_admin(user=Depends(require_auth)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


# ── Auth routes ────────────────────────────────────────────────────────────

@app.post("/auth/register", status_code=201)
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    ok, msg = register_user(db, req.username.strip(), req.email.strip(),
                             req.password, req.display_name or "")
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"status": "registered", "username": req.username}

@app.post("/auth/login")
def login(req: LoginRequest, db: Session = Depends(get_db)):
    token, msg = login_user(db, req.username.strip(), req.password)
    if not token:
        raise HTTPException(status_code=401, detail=msg)
    return {"token": token, "status": "ok"}

@app.post("/auth/logout")
def logout(request: Request, db: Session = Depends(get_db)):
    auth = request.headers.get("authorization") or request.headers.get("Authorization") or ""
    if auth.lower().startswith("bearer "):
        invalidate_token(db, auth.split(" ", 1)[1].strip())
    return {"status": "logged_out"}

@app.get("/auth/me")
def me(request: Request, db: Session = Depends(get_db), user=Depends(require_auth)):
    return {
        "id":           user.id,
        "username":     user.username,
        "email":        user.email,
        "display_name": user.display_name,
        "role":         user.role,
        "created_at":   user.created_at.isoformat() if user.created_at else None,
        "last_login":   user.last_login.isoformat()  if user.last_login  else None,
    }

@app.get("/auth/verify")
def verify_token(request: Request, db: Session = Depends(get_db)):
    """Debug endpoint — returns token validity without requiring full auth."""
    auth = request.headers.get("authorization") or request.headers.get("Authorization") or ""
    if not auth.lower().startswith("bearer "):
        return {"valid": False, "reason": "No Bearer token in request",
                "headers_received": dict(request.headers)}
    token = auth.split(" ", 1)[1].strip()
    user  = get_user_by_token(db, token)
    if not user:
        return {"valid": False, "reason": "Token not found or expired", "token_prefix": token[:8]+"..."}
    return {"valid": True, "username": user.username, "token_prefix": token[:8]+"..."}


# ── SOS routes ─────────────────────────────────────────────────────────────

def _fmt_alert(a):
    return {
        "id":            a.id,
        "username":      a.username,
        "display_name":  a.display_name,
        "message":       a.message,
        "severity":      a.severity,
        "status":        a.status,
        "latitude":      a.latitude,
        "longitude":     a.longitude,
        "location_name": a.location_name,
        "admin_note":    a.admin_note,
        "created_at":    a.created_at.isoformat() if a.created_at else None,
        "resolved_at":   a.resolved_at.isoformat() if a.resolved_at else None,
    }

@app.post("/sos", status_code=201)
def send_sos(req: SOSRequest, user=Depends(require_auth), db: Session = Depends(get_db)):
    alert = create_sos(
        db,
        user_id       = user.id,
        username      = user.username,
        display_name  = user.display_name or user.username,
        message       = req.message,
        severity      = req.severity or "HIGH",
        latitude      = req.latitude,
        longitude     = req.longitude,
        location_name = req.location_name,
    )
    return {"status": "sos_sent", "alert": _fmt_alert(alert)}

@app.get("/sos")
def get_sos_alerts(status: Optional[str] = None, user=Depends(require_auth),
                   db: Session = Depends(get_db)):
    alerts = list_sos(db, status=status)
    return {"alerts": [_fmt_alert(a) for a in alerts]}

@app.patch("/sos/{alert_id}")
def update_sos(alert_id: str, req: SOSUpdateRequest,
               user=Depends(require_auth), db: Session = Depends(get_db)):
    alert = update_sos_status(db, alert_id, req.status, req.admin_note)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    return {"status": "updated", "alert": _fmt_alert(alert)}


# ── Live Map data ──────────────────────────────────────────────────────────

# Static map POIs (disaster scenarios + infrastructure)
MAP_DATA = {
    "safe_zones": [
        {"id":"sz1","name":"Central Community Centre","lat":12.9716,"lng":77.5946,"capacity":500,"status":"open"},
        {"id":"sz2","name":"Cubbon Park Shelter","lat":12.9763,"lng":77.5929,"capacity":300,"status":"open"},
        {"id":"sz3","name":"Koramangala Sports Complex","lat":12.9352,"lng":77.6245,"capacity":800,"status":"open"},
        {"id":"sz4","name":"Indiranagar Grounds","lat":12.9784,"lng":77.6408,"capacity":400,"status":"open"},
        {"id":"sz5","name":"Whitefield Relief Camp","lat":12.9698,"lng":77.7500,"capacity":600,"status":"partial"},
        {"id":"sz6","name":"Jayanagar Convention Hall","lat":12.9250,"lng":77.5938,"capacity":350,"status":"open"},
    ],
    "hospitals": [
        {"id":"h1","name":"Manipal Hospital","lat":12.9591,"lng":77.6470,"beds":650,"emergency":True},
        {"id":"h2","name":"Apollo Hospital","lat":12.9670,"lng":77.6101,"beds":500,"emergency":True},
        {"id":"h3","name":"Fortis Hospital","lat":12.9631,"lng":77.6478,"beds":400,"emergency":True},
        {"id":"h4","name":"Narayana Health City","lat":12.8947,"lng":77.5848,"beds":800,"emergency":True},
        {"id":"h5","name":"St. John's Medical","lat":12.9414,"lng":77.6207,"beds":1200,"emergency":True},
        {"id":"h6","name":"Victoria Hospital","lat":12.9650,"lng":77.5780,"beds":900,"emergency":True},
        {"id":"h7","name":"Bowring Hospital","lat":12.9772,"lng":77.6027,"beds":600,"emergency":False},
        {"id":"h8","name":"Jayadeva Institute","lat":12.9209,"lng":77.5946,"beds":450,"emergency":True},
    ],
    "disaster_zones": [
        {"id":"dz1","name":"Flood Zone — Bellandur","lat":12.9344,"lng":77.6784,"type":"flood","severity":"HIGH","radius":1200},
        {"id":"dz2","name":"Fire Risk — Industrial Area","lat":12.9873,"lng":77.5592,"type":"fire","severity":"MEDIUM","radius":600},
        {"id":"dz3","name":"Chemical Spill — Peenya","lat":13.0284,"lng":77.5197,"type":"chemical_spill","severity":"CRITICAL","radius":900},
        {"id":"dz4","name":"Building Collapse Risk — BTM","lat":12.9166,"lng":77.6101,"type":"building_collapse","severity":"MEDIUM","radius":400},
        {"id":"dz5","name":"Earthquake Zone — Whitefield","lat":12.9698,"lng":77.7500,"type":"earthquake","severity":"LOW","radius":2000},
    ],
    "rescue_units": [
        {"id":"ru1","name":"Fire Station Alpha","lat":12.9789,"lng":77.5917,"type":"fire_truck","available":3},
        {"id":"ru2","name":"Ambulance Hub East","lat":12.9627,"lng":77.6459,"type":"ambulance","available":5},
        {"id":"ru3","name":"Rescue Team Koramangala","lat":12.9352,"lng":77.6245,"type":"rescue_team","available":2},
        {"id":"ru4","name":"Helicopter Base HAL","lat":12.9499,"lng":77.6680,"type":"helicopter","available":1},
    ],
}

@app.get("/map/data")
def get_map_data(user=Depends(require_auth)):
    return MAP_DATA

@app.get("/map/sos-pins")
def get_sos_pins(user=Depends(require_auth), db: Session = Depends(get_db)):
    """Return open SOS alerts that have GPS coords for map display."""
    alerts = list_sos(db, status="OPEN")
    pins   = [
        {
            "id":       a.id,
            "username": a.username,
            "message":  a.message,
            "severity": a.severity,
            "lat":      float(a.latitude)  if a.latitude  else None,
            "lng":      float(a.longitude) if a.longitude else None,
            "location_name": a.location_name,
            "created_at": a.created_at.isoformat() if a.created_at else None,
        }
        for a in alerts if a.latitude and a.longitude
    ]
    return {"pins": pins}


# ── Simulation routes ───────────────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "ok", "service": "Disaster Command API", "version": "3.0.0"}

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.get("/scenarios")
def list_scenarios(user=Depends(require_auth)):
    return {"scenarios": orchestrator.get_scenarios()}

@app.get("/scenarios/{scenario_id}")
def get_scenario(scenario_id: int, user=Depends(require_auth)):
    s = next((sc for sc in SCENARIOS if sc["id"] == scenario_id), None)
    if not s:
        raise HTTPException(status_code=404, detail="Scenario not found")
    return s

@app.post("/run")
def run_simulation(req: RunRequest, user=Depends(require_auth)):
    result = orchestrator.run(scenario_id=req.scenario_id, seed=req.seed)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@app.post("/run/custom")
def run_custom(req: CustomRunRequest, user=Depends(require_auth)):
    """Run a user-built scenario with arbitrary events."""
    scenario = {
        "name":   req.name,
        "events": [e.model_dump() for e in req.events],
    }
    result = orchestrator.run_custom(scenario=scenario, seed=req.seed or 42)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@app.post("/run/inject")
def inject_event(req: InjectEventRequest, user=Depends(require_auth)):
    """Inject a single event into the live simulation."""
    result = orchestrator.inject_event(event_def=req.model_dump(exclude={"seed"}),
                                       seed=req.seed)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@app.post("/run/nlp-parse")
async def nlp_parse(req: NLPParseRequest, user=Depends(require_auth)):
    """Parse a free-form description into structured scenario events.
    Uses Claude API if ANTHROPIC_API_KEY env var is set, otherwise falls back
    to a local rule-based parser so the feature works without an API key."""
    import httpx, json as _json, os, re

    # ── Local rule-based fallback ──────────────────────────────────────────
    def local_parse(text: str) -> dict:
        text_lower = text.lower()

        TYPE_KEYWORDS = {
            "flood": ["flood","flooding","inundation","water","submerge","deluge"],
            "fire":  ["fire","blaze","burning","flames","inferno","arson","wildfire"],
            "earthquake": ["earthquake","quake","tremor","seismic","aftershock"],
            "chemical_spill": ["chemical","spill","toxic","hazmat","gas leak","contamination","poison"],
            "building_collapse": ["collapse","collapsed","building collapse","structure","rubble","debris"],
        }
        SEV_KEYWORDS = {
            "CRITICAL": ["critical","catastrophic","massive","devastating","deadly","extreme","500","600","700","800","900","1000"],
            "HIGH":     ["high","major","serious","severe","significant","300","400"],
            "MEDIUM":   ["medium","moderate","moderate","significant","100","200"],
            "LOW":      ["low","minor","small","light","30","40","50"],
        }
        LOC_KEYWORDS = {
            "Downtown":    ["downtown","city center","central","cbd"],
            "Airport":     ["airport","airfield","terminal","runway"],
            "Harbor":      ["harbor","harbour","port","dock","waterfront","coast","shore"],
            "Hospital":    ["hospital","medical","clinic","health","emergency room"],
            "University":  ["university","campus","college","school","academia"],
            "Industrial":  ["industrial","factory","plant","warehouse","refinery","chemical"],
            "Residential": ["residential","suburb","neighborhood","housing","community","homes"],
            "Suburb":      ["suburb","outskirts","countryside","rural"],
            "Market":      ["market","bazaar","shopping","mall","commercial","store"],
            "Stadium":     ["stadium","arena","sports","concert","venue","crowd"],
        }

        # Detect disaster types
        found_types = []
        for dtype, kws in TYPE_KEYWORDS.items():
            if any(kw in text_lower for kw in kws):
                found_types.append(dtype)
        if not found_types:
            found_types = ["fire"]  # default

        # Detect severity
        severity = "MEDIUM"
        for sev, kws in SEV_KEYWORDS.items():
            if any(kw in text_lower for kw in kws):
                severity = sev
                break

        # Detect location
        location = "Downtown"
        for loc, kws in LOC_KEYWORDS.items():
            if any(kw in text_lower for kw in kws):
                location = loc
                break

        # Extract number of people
        nums = re.findall(r'\b(\d+)\b', text)
        affected = int(nums[0]) if nums else {"LOW":30,"MEDIUM":120,"HIGH":300,"CRITICAL":500}[severity]
        affected = max(10, min(1000, affected))

        # Build one event per found type (max 3)
        events = []
        locs = list(LOC_KEYWORDS.keys())
        for i, dtype in enumerate(found_types[:3]):
            events.append({
                "type": dtype,
                "severity": severity,
                "location": location if i == 0 else locs[(locs.index(location) + i) % len(locs)],
                "affected_people": affected if i == 0 else max(10, affected // 2),
            })

        title_words = text[:40].strip().rstrip(".,!?")
        return {"name": title_words, "events": events}

    # ── Try Claude API ─────────────────────────────────────────────────────
    api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()

    if not api_key:
        # No API key — use local parser
        parsed = local_parse(req.text)
        return {"parsed": parsed, "raw": None, "source": "local"}

    SYSTEM = """You are a disaster scenario parser for an emergency management system.
Convert the user's free-form description into a JSON object with this exact schema:
{
  "name": "short scenario title",
  "events": [
    {
      "type": one of [flood, fire, earthquake, chemical_spill, building_collapse],
      "severity": one of [LOW, MEDIUM, HIGH, CRITICAL],
      "location": one of [Downtown, Airport, Harbor, Hospital, University, Industrial, Residential, Suburb, Market, Stadium],
      "affected_people": integer between 10 and 1000
    }
  ]
}
Rules:
- Extract ALL disasters mentioned.
- Choose the nearest valid location from the list above.
- Infer severity from words like "minor"=LOW, "moderate"=MEDIUM, "major/serious"=HIGH, "catastrophic/critical"=CRITICAL.
- Infer affected_people from any numbers mentioned; otherwise estimate from severity: LOW=30, MEDIUM=120, HIGH=300, CRITICAL=500.
- Return ONLY valid JSON. No explanation, no markdown, no extra text."""

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "Content-Type":  "application/json",
                    "x-api-key":     api_key,
                    "anthropic-version": "2023-06-01",
                },
                json={
                    "model":      "claude-haiku-4-5-20251001",
                    "max_tokens": 512,
                    "system":     SYSTEM,
                    "messages":   [{"role": "user", "content": req.text}],
                },
            )
        data = resp.json()

        # Handle API-level errors (auth failure, rate limit, etc.)
        if "error" in data:
            print(f"[NLP] Claude API error: {data['error']} — falling back to local parser")
            parsed = local_parse(req.text)
            return {"parsed": parsed, "raw": None, "source": "local_fallback",
                    "api_error": data["error"].get("message", str(data["error"]))}

        raw = data["content"][0]["text"].strip()
        # Strip markdown fences if present
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        parsed = _json.loads(raw.strip())
        return {"parsed": parsed, "raw": raw, "source": "claude"}

    except Exception as e:
        # Any failure → fall back to local parser
        print(f"[NLP] Exception: {e} — falling back to local parser")
        parsed = local_parse(req.text)
        return {"parsed": parsed, "raw": None, "source": "local_fallback"}
